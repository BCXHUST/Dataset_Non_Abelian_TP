D=1.7;d=0.8;%D为柱子宽度，d为柱子间距

for i=1:1:12
    a1=0:0.1:D;%每个柱子的宽度
    aa = ['a',num2str(i),'=a1+(D+d)*(i-1);'];
    eval(aa);
    b1=0:0.1:D;%每个柱子的宽度
    bb = ['b',num2str(i),'=b1+(D+d)*(i-1);'];
    eval(bb);
end
a=[a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12];
b=[b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12];
z1=zeros(1+D*10,1+D*10)+0.001;%零矩阵行列为柱子宽度+1
z2=zeros(1+D*10,1+D*10)+0.001;
z3=zeros(1+D*10,1+D*10)+0.001;
figure(1)
for i=1:1:12
    cc=['a',num2str(i)];
    c=eval(cc);
    for j=1:1:12
        ee=['b',num2str(j)];
        e=eval(ee);
        surf(c,e,z1);
        hold on
    end
end

%% 1
%% 1_1
z4=zeros(12*(D*10+1),10*D+1+1)+0.001;
aa3=(1-1)*(D+d):0.1:(1-1)*(D+d)+D+0.1;
surf(aa3,b,z4);

%% 1_2
T11=10^(-0.695);T12=10^(-2.4536);
T21=10^(-2.8724);T22=10^(-3.14525);T23=10^(-4.2272);
T31=10^(-1.96955);T32=10^(-1.83835);T33=10^(-3.9643);
T=T11+T12+T21+T22+T23+T31+T32+T33;
%T=1;
%% 1_2-11
T11=T11/T;
z1=zeros(1+D*10,1+D*10)+T11;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T11/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T11/(D*10);
end
surf(a4,b1,z1);
hold on 
surf(a4,b1*0+(1-1)*(D+d),z2);
hold on 
surf(a4,b1*0+(1-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b1,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b1,z3);

%% 1_2-12
T12=T12/T;
z1=zeros(1+D*10,1+D*10)+T12;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T12/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T12/(D*10);
end
surf(a4,b4,z1);
hold on 
surf(a4,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a4,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b4,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b4,z3);

%% 1_2-21
T21=T21/T;
z1=zeros(1+D*10,1+D*10)+T21;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T21/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T21/(D*10);
end
surf(a4,b2,z1);
hold on 
surf(a4,b2*0+(2-1)*(D+d),z2);
hold on 
surf(a4,b2*0+(2-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b2,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b2,z3);

%% 1_2-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a4,b5,z1);
hold on 
surf(a4,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a4,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b5,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b5,z3);

%% 1_2-23
T23=T23/T;
z1=zeros(1+D*10,1+D*10)+T23;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T23/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T23/(D*10);
end
surf(a4,b8,z1);
hold on 
surf(a4,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a4,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b8,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b8,z3);

%% 1_2-31
T31=T31/T;
z1=zeros(1+D*10,1+D*10)+T31;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T31/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T31/(D*10);
end
surf(a4,b3,z1);
hold on 
surf(a4,b3*0+(3-1)*(D+d),z2);
hold on 
surf(a4,b3*0+(3-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b3,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b3,z3);

%% 1_2-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a4,b6,z1);
hold on 
surf(a4,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a4,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b6,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b6,z3);

%% 1_2-33
T33=T33/T;
z1=zeros(1+D*10,1+D*10)+T33;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T33/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T33/(D*10);
end
surf(a4,b9,z1);
hold on 
surf(a4,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a4,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b9,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b9,z3);

%% 1_3
T11=10^(-3.7225);T12=10^(-0.6578);T13=10^(-1.9153);T14=10^(-3.66925);
T21=10^(-3.52715);T22=10^(-1.9098);T23=10^(-1.9524);
T32=10^(-1.926);T33=10^(-1.92045);
T=T11+T12+T13+T14+T21+T22+T23+T32+T33;
%T=1;
%% 1_3-11
T11=T11/T;
z1=zeros(1+D*10,1+D*10)+T11;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T11/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T11/(D*10);
end
surf(a7,b1,z1);
hold on 
surf(a7,b1*0+(1-1)*(D+d),z2);
hold on 
surf(a7,b1*0+(1-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b1,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b1,z3);

%% 1_3-12
T12=T12/T;
z1=zeros(1+D*10,1+D*10)+T12;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T12/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T12/(D*10);
end
surf(a7,b4,z1);
hold on 
surf(a7,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a7,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b4,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b4,z3);

%% 1_3-13
T13=T13/T;
z1=zeros(1+D*10,1+D*10)+T13;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T13/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T13/(D*10);
end
surf(a7,b7,z1);
hold on 
surf(a7,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a7,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b7,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b7,z3);

%% 1_3-14
T14=T14/T;
z1=zeros(1+D*10,1+D*10)+T14;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T14/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T14/(D*10);
end
surf(a7,b10,z1);
hold on 
surf(a7,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a7,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b10,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b10,z3);

%% 1_3-21
T21=T21/T;
z1=zeros(1+D*10,1+D*10)+T21;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T21/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T21/(D*10);
end
surf(a7,b2,z1);
hold on 
surf(a7,b2*0+(2-1)*(D+d),z2);
hold on 
surf(a7,b2*0+(2-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b2,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b2,z3);

%% 1_3-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a7,b5,z1);
hold on 
surf(a7,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a7,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b5,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b5,z3);

%% 1_3-23
T23=T23/T;
z1=zeros(1+D*10,1+D*10)+T23;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T23/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T23/(D*10);
end
surf(a7,b8,z1);
hold on 
surf(a7,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a7,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b8,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b8,z3);

%% 1_3-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a7,b6,z1);
hold on 
surf(a7,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a7,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b6,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b6,z3);

%% 1_3-33
T33=T33/T;
z1=zeros(1+D*10,1+D*10)+T33;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T33/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T33/(D*10);
end
surf(a7,b9,z1);
hold on 
surf(a7,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a7,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b9,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b9,z3);

%% 1_4
T13=10^(-0.6462);T14=10^(-1.9999);
T22=10^(-4.21235);T23=10^(-1.78535);T24=10^(-1.86525);
T32=10^(-2.69385);T33=10^(-1.87545);T34=10^(-1.98935);
T=T13+T14+T22+T23+T24+T32+T33+T34;
%T=1;
%% 1_4-13
T13=T13/T;
z1=zeros(1+D*10,1+D*10)+T13;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T13/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T13/(D*10);
end
surf(a10,b7,z1);
hold on 
surf(a10,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a10,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a10*0+(10-1)*(D+d),b7,z3);
hold on 
surf(a10*0+(10-1)*(D+d)+D,b7,z3);

%% 1_4-14
T14=T14/T;
z1=zeros(1+D*10,1+D*10)+T14;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T14/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T14/(D*10);
end
surf(a10,b10,z1);
hold on 
surf(a10,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a10,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a10*0+(10-1)*(D+d),b10,z3);
hold on 
surf(a10*0+(10-1)*(D+d)+D,b10,z3);

%% 1_4-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a10,b5,z1);
hold on 
surf(a10,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a10,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a10*0+(10-1)*(D+d),b5,z3);
hold on 
surf(a10*0+(10-1)*(D+d)+D,b5,z3);

%% 1_4-23
T23=T23/T;
z1=zeros(1+D*10,1+D*10)+T23;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T23/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T23/(D*10);
end
surf(a10,b8,z1);
hold on 
surf(a10,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a10,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a10*0+(10-1)*(D+d),b8,z3);
hold on 
surf(a10*0+(10-1)*(D+d)+D,b8,z3);

%% 1_4-24
T24=T24/T;
z1=zeros(1+D*10,1+D*10)+T24;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T24/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T24/(D*10);
end
surf(a10,b11,z1);
hold on 
surf(a10,b11*0+(11-1)*(D+d),z2);
hold on 
surf(a10,b11*0+(11-1)*(D+d)+D,z2);
hold on 
surf(a10*0+(10-1)*(D+d),b11,z3);
hold on 
surf(a10*0+(10-1)*(D+d)+D,b11,z3);

%% 1_4-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a10,b6,z1);
hold on 
surf(a10,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a10,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a10*0+(10-1)*(D+d),b6,z3);
hold on 
surf(a10*0+(10-1)*(D+d)+D,b6,z3);

%% 1_4-33
T33=T33/T;
z1=zeros(1+D*10,1+D*10)+T33;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T33/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T33/(D*10);
end
surf(a10,b9,z1);
hold on 
surf(a10,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a10,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a10*0+(10-1)*(D+d),b9,z3);
hold on 
surf(a10*0+(10-1)*(D+d)+D,b9,z3);

%% 1_4-34
T34=T34/T;
z1=zeros(1+D*10,1+D*10)+T34;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T34/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T34/(D*10);
end
surf(a10,b12,z1);
hold on 
surf(a10,b12*0+(12-1)*(D+d),z2);
hold on 
surf(a10,b12*0+(12-1)*(D+d)+D,z2);
hold on 
surf(a10*0+(10-1)*(D+d),b12,z3);
hold on 
surf(a10*0+(10-1)*(D+d)+D,b12,z3);

%% 2
%% 2_1
T11=10^(-1.61005);
T21=10^(-0.3178);T22=10^(-4.0935);
T31=10^(-1.82795);T32=10^(-3.35805);
T=T11+T21+T22+T31+T32;
%T=1;
%% 2_1-11
T11=T11/T;
z1=zeros(1+D*10,1+D*10)+T11;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T11/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T11/(D*10);
end
surf(a2,b1,z1);
hold on 
surf(a2,b1*0+(1-1)*(D+d),z2);
hold on 
surf(a2,b1*0+(1-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b1,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b1,z3);

%% 2_1-21
T21=T21/T;
z1=zeros(1+D*10,1+D*10)+T21;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T21/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T21/(D*10);
end
surf(a2,b2,z1);
hold on 
surf(a2,b2*0+(2-1)*(D+d),z2);
hold on 
surf(a2,b2*0+(2-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b2,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b2,z3);

%% 2_1-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a2,b5,z1);
hold on 
surf(a2,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a2,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b5,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b5,z3);


%% 2_1-31
T31=T31/T;
z1=zeros(1+D*10,1+D*10)+T31;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T31/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T31/(D*10);
end
surf(a2,b3,z1);
hold on 
surf(a2,b3*0+(3-1)*(D+d),z2);
hold on 
surf(a2,b3*0+(3-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b3,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b3,z3);

%% 2_1-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a2,b6,z1);
hold on 
surf(a2,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a2,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b6,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b6,z3);

%% 2_2
T12=10^(-1.7541);
T21=10^(-4.2257);T22=10^(-0.4206);T23=10^(-4.4104);
T31=10^(-4.44865);T32=10^(-2.23685);T33=10^(-3.58585);
T=T12+T21+T22+T23+T31+T32+T33;
%T=1;
%% 2_2-12
T12=T12/T;
z1=zeros(1+D*10,1+D*10)+T12;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T12/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T12/(D*10);
end
surf(a5,b4,z1);
hold on 
surf(a5,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a5,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b4,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b4,z3);

%% 2_2-21
T21=T21/T;
z1=zeros(1+D*10,1+D*10)+T21;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T21/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T21/(D*10);
end
surf(a5,b2,z1);
hold on 
surf(a5,b2*0+(2-1)*(D+d),z2);
hold on 
surf(a5,b2*0+(2-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b2,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b2,z3);

%% 2_2-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a5,b5,z1);
hold on 
surf(a5,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a5,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b5,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b5,z3);

%% 2_2-23
T23=T23/T;
z1=zeros(1+D*10,1+D*10)+T23;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T23/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T23/(D*10);
end
surf(a5,b8,z1);
hold on 
surf(a5,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a5,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b8,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b8,z3);

%% 2_2-31
T31=T31/T;
z1=zeros(1+D*10,1+D*10)+T31;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T31/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T31/(D*10);
end
surf(a5,b3,z1);
hold on 
surf(a5,b3*0+(3-1)*(D+d),z2);
hold on 
surf(a5,b3*0+(3-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b3,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b3,z3);

%% 2_2-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a5,b6,z1);
hold on 
surf(a5,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a5,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b6,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b6,z3);

%% 2_2-33
T33=T33/T;
z1=zeros(1+D*10,1+D*10)+T33;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T33/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T33/(D*10);
end
surf(a5,b9,z1);
hold on 
surf(a5,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a5,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b9,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b9,z3);

%% 2_3
T13=10^(-1.6352);T14=10^(-4.07595);
T22=10^(-4.2288);T23=10^(-0.4504);T24=10^(-3.82985);
T32=10^(-3.1252);T33=10^(-1.69595);T34=10^(-3.8022);
T=T13+T14+T22+T23+T24+T32+T33+T34;
%T=1;
%% 2_3-13
T13=T13/T;
z1=zeros(1+D*10,1+D*10)+T13;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T13/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T13/(D*10);
end
surf(a8,b7,z1);
hold on 
surf(a8,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a8,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b7,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b7,z3);

%% 2_3-14
T14=T14/T;
z1=zeros(1+D*10,1+D*10)+T14;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T14/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T14/(D*10);
end
surf(a8,b10,z1);
hold on 
surf(a8,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a8,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b10,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b10,z3);

%% 2_3-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a8,b5,z1);
hold on 
surf(a8,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a8,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b5,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b5,z3);

%% 2_3-23
T23=T23/T;
z1=zeros(1+D*10,1+D*10)+T23;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T23/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T23/(D*10);
end
surf(a8,b8,z1);
hold on 
surf(a8,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a8,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b8,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b8,z3);

%% 2_3-24
T24=T24/T;
z1=zeros(1+D*10,1+D*10)+T24;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T24/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T24/(D*10);
end
surf(a8,b11,z1);
hold on 
surf(a8,b11*0+(11-1)*(D+d),z2);
hold on 
surf(a8,b11*0+(11-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b11,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b11,z3);

%% 2_3-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a8,b6,z1);
hold on 
surf(a8,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a8,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b6,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b6,z3);

%% 2_3-33
T33=T33/T;
z1=zeros(1+D*10,1+D*10)+T33;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T33/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T33/(D*10);
end
surf(a8,b9,z1);
hold on 
surf(a8,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a8,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b9,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b9,z3);

%% 2_3-34
T34=T34/T;
z1=zeros(1+D*10,1+D*10)+T34;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T34/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T34/(D*10);
end
surf(a8,b12,z1);
hold on 
surf(a8,b12*0+(12-1)*(D+d),z2);
hold on 
surf(a8,b12*0+(12-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b12,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b12,z3);

%% 2_4
T14=10^(-1.53615);
T24=10^(-0.4349);
T32=10^(-3.6454);T34=10^(-1.6095);
T=T14++T24+T32+T34;
%T=1;
%% 2_4-14
T14=T14/T;
z1=zeros(1+D*10,1+D*10)+T14;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T14/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T14/(D*10);
end
surf(a11,b10,z1);
hold on 
surf(a11,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a11,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a11*0+(11-1)*(D+d),b10,z3);
hold on 
surf(a11*0+(11-1)*(D+d)+D,b10,z3);

%% 2_4-24
T24=T24/T;
z1=zeros(1+D*10,1+D*10)+T24;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T24/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T24/(D*10);
end
surf(a11,b11,z1);
hold on 
surf(a11,b11*0+(11-1)*(D+d),z2);
hold on 
surf(a11,b11*0+(11-1)*(D+d)+D,z2);
hold on 
surf(a11*0+(11-1)*(D+d),b11,z3);
hold on 
surf(a11*0+(11-1)*(D+d)+D,b11,z3);

%% 2_4-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a11,b6,z1);
hold on 
surf(a11,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a11,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a11*0+(11-1)*(D+d),b6,z3);
hold on 
surf(a11*0+(11-1)*(D+d)+D,b6,z3);

%% 2_4-34
T34=T34/T;
z1=zeros(1+D*10,1+D*10)+T34;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T34/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T34/(D*10);
end
surf(a11,b12,z1);
hold on 
surf(a11,b12*0+(12-1)*(D+d),z2);
hold on 
surf(a11,b12*0+(12-1)*(D+d)+D,z2);
hold on 
surf(a11*0+(11-1)*(D+d),b12,z3);
hold on 
surf(a11*0+(11-1)*(D+d)+D,b12,z3);

%% 3
%% 3_1
T11=10^(-1.82265);T12=10^(-1.90495);T13=10^(-4.2732);
T21=10^(-3.30015);T22=10^(-1.7054);
T31=10^(-2.0825);T32=10^(-0.4436);
T=T11+T12+T13+T21+T22+T31+T32;
%T=1;
%% 3_1-11
T11=T11/T;
z1=zeros(1+D*10,1+D*10)+T11;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T11/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T11/(D*10);
end
surf(a3,b1,z1);
hold on 
surf(a3,b1*0+(1-1)*(D+d),z2);
hold on 
surf(a3,b1*0+(1-1)*(D+d)+D,z2);
hold on 
surf(a3*0+(3-1)*(D+d),b1,z3);
hold on 
surf(a3*0+(3-1)*(D+d)+D,b1,z3);

%% 3_1-12
T12=T12/T;
z1=zeros(1+D*10,1+D*10)+T12;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T12/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T12/(D*10);
end
surf(a3,b4,z1);
hold on 
surf(a3,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a3,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a3*0+(3-1)*(D+d),b4,z3);
hold on 
surf(a3*0+(3-1)*(D+d)+D,b4,z3);

%% 3_1-13
T13=T13/T;
z1=zeros(1+D*10,1+D*10)+T13;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T13/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T13/(D*10);
end
surf(a3,b7,z1);
hold on 
surf(a3,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a3,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a3*0+(3-1)*(D+d),b7,z3);
hold on 
surf(a3*0+(3-1)*(D+d)+D,b7,z3);

%% 3_1-21
T21=T21/T;
z1=zeros(1+D*10,1+D*10)+T21;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T21/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T21/(D*10);
end
surf(a3,b2,z1);
hold on 
surf(a3,b2*0+(2-1)*(D+d),z2);
hold on 
surf(a3,b2*0+(2-1)*(D+d)+D,z2);
hold on 
surf(a3*0+(3-1)*(D+d),b2,z3);
hold on 
surf(a3*0+(3-1)*(D+d)+D,b2,z3);

%% 3_1-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a3,b5,z1);
hold on 
surf(a3,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a3,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a3*0+(3-1)*(D+d),b5,z3);
hold on 
surf(a3*0+(3-1)*(D+d)+D,b5,z3);

%% 3_1-31
T31=T31/T;
z1=zeros(1+D*10,1+D*10)+T31;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T31/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T31/(D*10);
end
surf(a3,b3,z1);
hold on 
surf(a3,b3*0+(3-1)*(D+d),z2);
hold on 
surf(a3,b3*0+(3-1)*(D+d)+D,z2);
hold on 
surf(a3*0+(3-1)*(D+d),b3,z3);
hold on 
surf(a3*0+(3-1)*(D+d)+D,b3,z3);

%% 3_1-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a3,b6,z1);
hold on 
surf(a3,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a3,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a3*0+(3-1)*(D+d),b6,z3);
hold on 
surf(a3*0+(3-1)*(D+d)+D,b6,z3);

%% 3_2
T12=10^(-1.9616);T13=10^(-1.68795);T14=10^(-3.5909);
T22=10^(-1.92145);T23=10^(-1.7525);
T31=10^(-3.79215);T32=10^(-1.7843);T33=10^(-0.414);T34=10^(-4.1595);
T=T12+T13+T14+T22+T23+T31+T32+T33+T34;
%T=1;
%% 3_2-12
T12=T12/T;
z1=zeros(1+D*10,1+D*10)+T12;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T12/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T12/(D*10);
end
surf(a6,b4,z1);
hold on 
surf(a6,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a6,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b4,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b4,z3);

%% 3_2-13
T13=T13/T;
z1=zeros(1+D*10,1+D*10)+T13;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T13/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T13/(D*10);
end
surf(a6,b7,z1);
hold on 
surf(a6,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a6,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b7,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b7,z3);

%% 3_2-14
T14=T14/T;
z1=zeros(1+D*10,1+D*10)+T14;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T14/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T14/(D*10);
end
surf(a6,b10,z1);
hold on 
surf(a6,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a6,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b10,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b10,z3);

%% 3_2-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a6,b5,z1);
hold on 
surf(a6,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a6,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b5,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b5,z3);

%% 3_2-23
T23=T23/T;
z1=zeros(1+D*10,1+D*10)+T23;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T23/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T23/(D*10);
end
surf(a6,b8,z1);
hold on 
surf(a6,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a6,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b8,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b8,z3);

%% 3_2-31
T31=T31/T;
z1=zeros(1+D*10,1+D*10)+T31;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T31/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T31/(D*10);
end
surf(a6,b3,z1);
hold on 
surf(a6,b3*0+(3-1)*(D+d),z2);
hold on 
surf(a6,b3*0+(3-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b3,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b3,z3);

%% 3_2-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a6,b6,z1);
hold on 
surf(a6,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a6,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b6,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b6,z3);

%% 3_2-33
T33=T33/T;
z1=zeros(1+D*10,1+D*10)+T33;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T33/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T33/(D*10);
end
surf(a6,b9,z1);
hold on 
surf(a6,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a6,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b9,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b9,z3);

%% 3_2-34
T34=T34/T;
z1=zeros(1+D*10,1+D*10)+T34;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T34/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T34/(D*10);
end
surf(a6,b12,z1);
hold on 
surf(a6,b12*0+(12-1)*(D+d),z2);
hold on 
surf(a6,b12*0+(12-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b12,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b12,z3);

%% 3_3
T13=10^(-1.61715);T14=10^(-1.564);
T23=10^(-1.8496);T24=10^(-1.6636);
T32=10^(-2.47445);T33=10^(-1.8343);T34=10^(-0.4353);
T=T13+T14+T23+T24+T32+T33+T34;
%T=1;
%% 3_3-13
T13=T13/T;
z1=zeros(1+D*10,1+D*10)+T13;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T13/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T13/(D*10);
end
surf(a9,b7,z1);
hold on 
surf(a9,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a9,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b7,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b7,z3);

%% 3_3-14
T14=T14/T;
z1=zeros(1+D*10,1+D*10)+T14;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T14/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T14/(D*10);
end
surf(a9,b10,z1);
hold on 
surf(a9,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a9,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b10,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b10,z3);

%% 3_3-23
T23=T23/T;
z1=zeros(1+D*10,1+D*10)+T23;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T23/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T23/(D*10);
end
surf(a9,b8,z1);
hold on 
surf(a9,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a9,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b8,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b8,z3);

%% 3_3-24
T24=T24/T;
z1=zeros(1+D*10,1+D*10)+T24;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T24/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T24/(D*10);
end
surf(a9,b11,z1);
hold on 
surf(a9,b11*0+(11-1)*(D+d),z2);
hold on 
surf(a9,b11*0+(11-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b11,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b11,z3);

%% 3_3-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a9,b6,z1);
hold on 
surf(a9,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a9,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b6,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b6,z3);

%% 3_3-33
T33=T33/T;
z1=zeros(1+D*10,1+D*10)+T33;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T33/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T33/(D*10);
end
surf(a9,b9,z1);
hold on 
surf(a9,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a9,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b9,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b9,z3);

%% 3_3-34
T34=T34/T;
z1=zeros(1+D*10,1+D*10)+T34;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T34/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T34/(D*10);
end
surf(a9,b12,z1);
hold on 
surf(a9,b12*0+(12-1)*(D+d),z2);
hold on 
surf(a9,b12*0+(12-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b12,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b12,z3);

%% 3_4
z4=zeros(12*(D*10+1),10*D+1+1)+0.001;
aa3=(12-1)*(D+d)-0.1:0.1:(12-1)*(D+d)+D;
surf(aa3,b,z4);

shading flat%网格化


%%边界
p1=0:0.1:(12-1)*(D+d)+D;
q1=(12-1)*(D+d)+D+0*p1;
z1=1+0*p1;
plot3(p1,q1,z1,'color',[0.75 0.75 0.75],'linewidth',1);

q2=0.1:0.1:(12-1)*(D+d)+D;
p2=(12-1)*(D+d)+D+0*q2;
z2=1+0*q2;
plot3(p2,q2,z2,'color',[0.75 0.75 0.75],'linewidth',1);

z3=0:0.1:1;
p3=0+0*z3;
q3=(12-1)*(D+d)+D+0*z3;
p4=(12-1)*(D+d)+D+0*z3;
q4=(12-1)*(D+d)+D+0*z3;
p5=(12-1)*(D+d)+D+0*z3;
q5=0.1+0*z3;
plot3(p3,q3,z3,'color',[0.75 0.75 0.75],'linewidth',1);
hold on
plot3(p4,q4,z3,'color',[0.75 0.75 0.75],'linewidth',1);
hold on
plot3(p5,q5,z3,'color',[0.75 0.75 0.75],'linewidth',1);

% %%短线
% q6=(12-1)*(D+d)+D:0.1:(12-1)*(D+d)+D+0.6*D;
% p6=0*q6;
% z6=0+0*q6;z7=0.5+0*q6;z8=1+0*q6;
% plot3(p6,q6,z6,'color',[0 0 0],'linewidth',1.5);
% hold on
% plot3(p6,q6,z7,'color',[0 0 0],'linewidth',1.5);
% hold on
% plot3(p6,q6,z8,'color',[0 0 0],'linewidth',1.5);
% 
% for i=1:1:12
%     p=-0.6*D:0.1:0;
%     q=(i-1)*(D+d)+0.5*D+0*p;
%     z=0*p;
%     plot3(p,q,z,'color',[0 0 0],'linewidth',1.5);
%     hold on
% end
% 
% for i=1:1:12
%     q=-0.6*D:0.1:0;
%     p=(i-1)*(D+d)+0.5*D+0*q;
%     z=0*q;
%     plot3(p,q,z,'color',[0 0 0],'linewidth',1.5);
%     hold on
% end


colorbar; colormap(hot);
clim([0 1]);
view(-64.8131,76.8)

set(gca,'xcolor',[1 1 1]);
set(gca,'ycolor',[1 1 1]);
set(gca,'zcolor',[1 1 1]);
set(gcf,'color',[1 1 1]);



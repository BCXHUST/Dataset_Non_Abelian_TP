N=501;

%num='13';

ss=['2-1-3-23-21-1';'2-1-3-23-22-1';'2-1-3-23-23-1';'2-1-3-23-32-1';'2-1-3-23-42-1'];

for nn=1:1:5
fid = fopen([ss(nn,:),'.csv'], 'r');                                          
symble=0;
D1=zeros(1,N);
D2=zeros(1,N);
while ~feof(fid)
    tline=fgetl(fid);
    if ~isempty(tline)
        if symble==0
            if tline(2)=='['
                symble=symble+1;
            end
        elseif symble>0
            data=textscan(tline,'%f,%f');
            data=cell2mat(data);
            D1(symble)=data(1); %波长
            D2(symble)=data(2); %数据
            symble=symble+1;
            clear data
        end
    end
end
fclose(fid);

sss=['TE2';'R12';'R22';'R13';'R14'];
eval(['a',sss(nn,:),'=D2;']);
end
l=D1; 
figure(1);
hold on
plot(l,aTE2-s3342-s1142);
plot(l,aR12-s3342-s2242);
plot(l,aR22-s3342-s3342,'color',[0,0,0]);
plot(l,aR13-s3342-s2243);
plot(l,aR14-s3342-s2244);
%legend('TE2','R12','R22','R13','R14');
axis([1540,1560,-50,5]);
%axis([1550,1560,-50,10]);
% plot(lambda,10*log10(TTT43));
% hold on;
% plot(lambda,10*log10(TTT44));
% hold on;
% plot(lambda,10*log10(TTT44),'--');
% hold on;
% plot(lambda,10*log10(TTT34));
% axis([1400,1700,-50,0]);

%title('TE输入');
%figure(2);
%hold on
%plot(l,a23-s1-s2);
%plot(l,a24-s2-s2);
%plot(l,a42-s1-s2);
%plot(l,a41-s2-s2);
%title('TM输入');
% axis([1530,1570,-50,0]);
% plot(lambda,10*log10(TTT43));
% hold on;
% plot(lambda,10*log10(TTT33));
% hold on;
% plot(lambda,10*log10(TTT33),'--');
% hold on;
% plot(lambda,10*log10(TTT34));
% hold on;





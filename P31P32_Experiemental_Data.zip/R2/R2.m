for i=1:1:12
    a1=0:0.1:2;
    aa = ['a',num2str(i),'=a1+2.5*(i-1);'];
    eval(aa);
    b1=0:0.1:2;
    bb = ['b',num2str(i),'=b1+2.5*(i-1);'];
    eval(bb);
end
a=[a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12];
b=[b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12];
z1=zeros(21,21)+0.001;
figure(1)
for i=1:1:12
    cc=['a',num2str(i)];
    c=eval(cc);
    for j=1:1:12
        dd=['b',num2str(j)];
        d=eval(dd);
        surf(c,d,z1);
        hold on
    end
end

%% R2_1
TE1=10^(-2.32205);R11=10^(-1.78655);R21=10^(-0.1382);TE2=10^(-2.82795);R12=10^(-2.3918);
T=TE1+R11+R21+TE2+R12;

%% R2_1-TE_1
TE1=TE1/T;
z1=zeros(21,21)+TE1;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE1/20;
    z3(:,i)=z1(:,i)-(i-1)*TE1/20;
end
surf(a3,b1,z1);
hold on 
surf(a3,b1*0,z2);
hold on 
surf(a3,b1*0+2,z2);
hold on 
surf(a3*0+5,b1,z3);
hold on 
surf(a3*0+7,b1,z3);

%% R2_1-R1_1
R11=R11/T;
z1=zeros(21,21)+R11;
for i=1:1:20
    z2(i,:)=z1(i,:)-(i-1)*R11/20;
    z3(:,i)=z1(:,i)-(i-1)*R11/20;
end
surf(a3,b2,z1);
hold on 
surf(a3,b2*0+2.5,z2);
hold on 
surf(a3,b2*0+4.5,z2);
hold on 
surf(a3*0+5,b2,z3);
hold on 
surf(a3*0+7,b2,z3);

%% R2_1-R2_1
R21=R21/T;
z1=zeros(21,21)+R21;
for i=1:1:20
    z2(i,:)=z1(i,:)-(i-1)*R21/20;
    z3(:,i)=z1(:,i)-(i-1)*R21/20;
end
surf(a3,b3,z1);
hold on 
surf(a3,b3*0+5,z2);
hold on 
surf(a3,b3*0+7,z2);
hold on 
surf(a3*0+5,b3,z3);
hold on 
surf(a3*0+7,b3,z3);

%% R2_1-TE_2
TE2=TE2/T;
z1=zeros(21,21)+TE2;
for i=1:1:20
    z2(i,:)=z1(i,:)-(i-1)*TE2/20;
    z3(:,i)=z1(:,i)-(i-1)*TE2/20;
end
surf(a3,b4,z1);
hold on 
surf(a3,b4*0+7.5,z2);
hold on 
surf(a3,b4*0+9.5,z2);
hold on 
surf(a3*0+5,b4,z3);
hold on 
surf(a3*0+7,b4,z3);

%% R2_1-R1_2
R12=R12/T;
z1=zeros(21,21)+R12;
for i=1:1:20
    z2(i,:)=z1(i,:)-(i-1)*R12/20;
    z3(:,i)=z1(:,i)-(i-1)*R12/20;
end
surf(a3,b5,z1);
hold on 
surf(a3,b5*0+10,z2);
hold on 
surf(a3,b5*0+12,z2);
hold on 
surf(a3*0+5,b5,z3);
hold on 
surf(a3*0+7,b5,z3);

%% R2_2
TE2=10^(-0.9876);R12=10^(-1.99955);R22=10^(0.0898);R13=10^(-3.9418);R14=10^(-1.4851);
T=TE2+R12+R22+R13+R14;

%% R2_2-TE_2
TE2=TE2/T;
z1=zeros(21,21)+TE2;
for i=1:1:20
    z2(i,:)=z1(i,:)-(i-1)*TE2/20;
    z3(:,i)=z1(:,i)-(i-1)*TE2/20;
end
surf(a6,b4,z1);
hold on 
surf(a6,b4*0+7.5,z2);
hold on 
surf(a6,b4*0+9.5,z2);
hold on 
surf(a6*0+12.5,b4,z3);
hold on 
surf(a6*0+14.5,b4,z3);

%% R2_2-R1_2
R12=R12/T;
z1=zeros(21,21)+R12;
for i=1:1:20
    z2(i,:)=z1(i,:)-(i-1)*R12/20;
    z3(:,i)=z1(:,i)-(i-1)*R12/20;
end
surf(a6,b5,z1);
hold on 
surf(a6,b5*0+10,z2);
hold on 
surf(a6,b5*0+12,z2);
hold on 
surf(a6*0+12.5,b5,z3);
hold on 
surf(a6*0+14.5,b5,z3);

%% R2_2-R2_2
R22=R22/T;
z1=zeros(21,21)+R22;
for i=1:1:20
    z2(i,:)=z1(i,:)-(i-1)*R22/20;
    z3(:,i)=z1(:,i)-(i-1)*R22/20;
end
surf(a6,b6,z1);
hold on 
surf(a6,b6*0+12.5,z2);
hold on 
surf(a6,b6*0+14.5,z2);
hold on 
surf(a6*0+12.5,b6,z3);
hold on 
surf(a6*0+14.5,b6,z3);

%% R2_2-R1_3
R13=R13/T;
z1=zeros(21,21)+R13;
for i=1:1:20
    z2(i,:)=z1(i,:)-(i-1)*R13/20;
    z3(:,i)=z1(:,i)-(i-1)*R13/20;
end
surf(a6,b8,z1);
hold on 
surf(a6,b8*0+17.5,z2);
hold on 
surf(a6,b8*0+19.5,z2);
hold on 
surf(a6*0+12.5,b8,z3);
hold on 
surf(a6*0+14.5,b8,z3);

%% R2_2-R1_4
R14=R14/T;
z1=zeros(21,21)+R14;
for i=1:1:20
    z2(i,:)=z1(i,:)-(i-1)*R14/20;
    z3(:,i)=z1(:,i)-(i-1)*R14/20;
end
surf(a6,b11,z1);
hold on 
surf(a6,b11*0+25,z2);
hold on 
surf(a6,b11*0+27,z2);
hold on 
surf(a6*0+12.5,b11,z3);
hold on 
surf(a6*0+14.5,b11,z3);

%% R2_3
TE2=10^(-2.5483);R12=10^(-1.77795);TE3=10^(-1.58345);R13=10^(-0.8867);R23=10^(-0.1571);
T=TE2+R12+TE3+R13+R23;

%% R2_3-TE_2
TE2=TE2/T;
z1=zeros(21,21)+TE2;
for i=1:1:20
    z2(i,:)=z1(i,:)-(i-1)*TE2/20;
    z3(:,i)=z1(:,i)-(i-1)*TE2/20;
end
surf(a9,b4,z1);
hold on 
surf(a9,b4*0+7.5,z2);
hold on 
surf(a9,b4*0+9.5,z2);
hold on 
surf(a9*0+20,b4,z3);
hold on 
surf(a9*0+22,b4,z3);

%% R2_3-R1_2
R12=R12/T;
z1=zeros(21,21)+R12;
for i=1:1:20
    z2(i,:)=z1(i,:)-(i-1)*R12/20;
    z3(:,i)=z1(:,i)-(i-1)*R12/20;
end
surf(a9,b5,z1);
hold on 
surf(a9,b5*0+10,z2);
hold on 
surf(a9,b5*0+12,z2);
hold on 
surf(a9*0+20,b5,z3);
hold on 
surf(a9*0+22,b5,z3);

%% R2_3-TE_3
TE3=TE3/T;
z1=zeros(21,21)+TE3;
for i=1:1:20
    z2(i,:)=z1(i,:)-(i-1)*TE3/20;
    z3(:,i)=z1(:,i)-(i-1)*TE3/20;
end
surf(a9,b7,z1);
hold on 
surf(a9,b7*0+15,z2);
hold on 
surf(a9,b7*0+17,z2);
hold on 
surf(a9*0+20,b7,z3);
hold on 
surf(a9*0+22,b7,z3);

%% R2_3-R1_3
R13=R13/T;
z1=zeros(21,21)+R13;
for i=1:1:20
    z2(i,:)=z1(i,:)-(i-1)*R13/20;
    z3(:,i)=z1(:,i)-(i-1)*R13/20;
end
surf(a9,b8,z1);
hold on 
surf(a9,b8*0+17.5,z2);
hold on 
surf(a9,b8*0+19.5,z2);
hold on 
surf(a9*0+20,b8,z3);
hold on 
surf(a9*0+22,b8,z3);

%% R2_3-R2_3
R23=R23/T;
z1=zeros(21,21)+R23;
for i=1:1:20
    z2(i,:)=z1(i,:)-(i-1)*R23/20;
    z3(:,i)=z1(:,i)-(i-1)*R23/20;
end
surf(a9,b9,z1);
hold on 
surf(a9,b9*0+20,z2);
hold on 
surf(a9,b9*0+22,z2);
hold on 
surf(a9*0+20,b9,z3);
hold on 
surf(a9*0+22,b9,z3);

%% R2_4
TE4=10^(-1.3643);R14=10^(-1.2209);R24=10^(-0.15);
T=TE4+R14+R24;

%% R2_4-TE_4
TE4=TE4/T;
z1=zeros(21,21)+TE4;
for i=1:1:20
    z2(i,:)=z1(i,:)-(i-1)*TE4/20;
    z3(:,i)=z1(:,i)-(i-1)*TE4/20;
end
surf(a12,b10,z1);
hold on 
surf(a12,b10*0+22.5,z2);
hold on 
surf(a12,b10*0+24.5,z2);
hold on 
surf(a12*0+27.5,b10,z3);
hold on 
surf(a12*0+29.5,b10,z3);

%% R2_4-R1_4
R14=R14/T;
z1=zeros(21,21)+R14;
for i=1:1:20
    z2(i,:)=z1(i,:)-(i-1)*R14/20;
    z3(:,i)=z1(:,i)-(i-1)*R14/20;
end
surf(a12,b11,z1);
hold on 
surf(a12,b11*0+25,z2);
hold on 
surf(a12,b11*0+27,z2);
hold on 
surf(a12*0+27.5,b11,z3);
hold on 
surf(a12*0+29.5,b11,z3);

%% R2_4-R2_4
R24=R24/T;
z1=zeros(21,21)+R24;
for i=1:1:20
    z2(i,:)=z1(i,:)-(i-1)*R24/20;
    z3(:,i)=z1(:,i)-(i-1)*R24/20;
end
surf(a12,b12,z1);
hold on 
surf(a12,b12*0+27.5,z2);
hold on 
surf(a12,b12*0+29.5,z2);
hold on 
surf(a12*0+27.5,b12,z3);
hold on 
surf(a12*0+29.5,b12,z3);

xlim([0,30]);
ylim([0,30]);
zlim([0,1]);
shading flat

view(-45,60)



for i=1:1:12
    a1=0:0.1:1.7;
    aa = ['a',num2str(i),'=a1+2.5*(i-1);'];
    eval(aa);
    b1=0:0.1:1.7;
    bb = ['b',num2str(i),'=b1+2.5*(i-1);'];
    eval(bb);
end
a=[a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12];
b=[b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12];
z1=zeros(18,18)+0.001;
z2=zeros(18,18)+0.001;
z3=zeros(18,18)+0.001;
figure(1)
for i=1:1:12
    cc=['a',num2str(i)];
    c=eval(cc);
    for j=1:1:12
        dd=['b',num2str(j)];
        d=eval(dd);
        surf(c,d,z1);
        hold on
    end
end

D=1.7;d=0.8;

%% TE_1
TE1=10^(-1.4436);R21=10^(-1.48225);TE2=10^(-0.1601);R12=10^(-3.21485);TE3=10^(-1.58725);TE4=10^(-1.7355);
T=TE1+R21+TE2+R12+TE3+TE4;
%T=1;

%% TE_1-TE_1
TE1=TE1/T;
z1=zeros(18,18)+TE1;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE1/17;
    z3(:,i)=z1(:,i)-(i-1)*TE1/17;
end
surf(a1,b1,z1);
hold on 
surf(a1,b1*0+(1-1)*(D+d),z2);
hold on 
surf(a1,b1*0+(1-1)*(D+d)+D,z2);
hold on 
surf(a1*0+(1-1)*(D+d),b1,z3);
hold on 
surf(a1*0+(1-1)*(D+d)+D,b1,z3);

%% TE_1-R2_1
R21=R21/T;
z1=zeros(18,18)+R21;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R21/17;
    z3(:,i)=z1(:,i)-(i-1)*R21/17;
end
surf(a1,b3,z1);
hold on 
surf(a1,b3*0+(3-1)*(D+d),z2);
hold on 
surf(a1,b3*0+(3-1)*(D+d)+D,z2);
hold on 
surf(a1*0+(1-1)*(D+d),b3,z3);
hold on 
surf(a1*0+(1-1)*(D+d)+D,b3,z3);

%% TE_1-TE_2
TE2=TE2/T;
z1=zeros(18,18)+TE2;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE2/17;
    z3(:,i)=z1(:,i)-(i-1)*TE2/17;
end
surf(a1,b4,z1);
hold on 
surf(a1,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a1,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a1*0+(1-1)*(D+d),b4,z3);
hold on 
surf(a1*0+(1-1)*(D+d)+D,b4,z3);

%% TE_1-R1_2
R12=R12/T;
z1=zeros(18,18)+R12;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R12/17;
    z3(:,i)=z1(:,i)-(i-1)*R12/17;
end
surf(a1,b5,z1);
hold on 
surf(a1,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a1,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a1*0+(1-1)*(D+d),b5,z3);
hold on 
surf(a1*0+(1-1)*(D+d)+D,b5,z3);

%% TE_1-TE_3
TE3=TE3/T;
z1=zeros(18,18)+TE3;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE3/17;
    z3(:,i)=z1(:,i)-(i-1)*TE3/17;
end
surf(a1,b7,z1);
hold on 
surf(a1,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a1,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a1*0+(1-1)*(D+d),b7,z3);
hold on 
surf(a1*0+(1-1)*(D+d)+D,b7,z3);

%% TE_1-TE_4
TE4=TE4/T;
z1=zeros(18,18)+TE4;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE4/17;
    z3(:,i)=z1(:,i)-(i-1)*TE4/17;
end
surf(a1,b10,z1);
hold on 
surf(a1,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a1,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a1*0+(1-1)*(D+d),b10,z3);
hold on 
surf(a1*0+(1-1)*(D+d)+D,b10,z3);

%% TE_2
TE1=10^(-2.0539);R11=10^(-1.524);R21=10^(-1.79175);TE2=10^(-1.4328);R12=10^(-1.46135);R22=10^(-1.5056);
TE3=10^(-0.20945);R23=10^(-4.0098);TE4=10^(-1.4271);R24=10^(-2.693);
T=TE1+R11+R21+TE2+R12+R22+TE3+R23+TE4+R24;
%T=1;

%% TE_2-TE_1
TE1=TE1/T;
z1=zeros(18,18)+TE1;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE1/17;
    z3(:,i)=z1(:,i)-(i-1)*TE1/17;
end
surf(a4,b1,z1);
hold on 
surf(a4,b1*0+(1-1)*(D+d),z2);
hold on 
surf(a4,b1*0+(1-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b1,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b1,z3);

%% TE_2-R1_1
R11=R11/T;
z1=zeros(18,18)+R11;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R11/17;
    z3(:,i)=z1(:,i)-(i-1)*R11/17;
end
surf(a4,b2,z1);
hold on 
surf(a4,b2*0+(2-1)*(D+d),z2);
hold on 
surf(a4,b2*0+(2-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b2,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b2,z3);

%% TE_2-R2_1
R21=R21/T;
z1=zeros(18,18)+R21;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R21/17;
    z3(:,i)=z1(:,i)-(i-1)*R21/17;
end
surf(a4,b3,z1);
hold on 
surf(a4,b3*0+(3-1)*(D+d),z2);
hold on 
surf(a4,b3*0+(3-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b3,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b3,z3);

%% TE_2-TE_2
TE2=TE2/T;
z1=zeros(18,18)+TE2;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE2/17;
    z3(:,i)=z1(:,i)-(i-1)*TE2/17;
end
surf(a4,b4,z1);
hold on 
surf(a4,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a4,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b4,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b4,z3);

%% TE_2-R1_2
R12=R12/T;
z1=zeros(18,18)+R12;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R12/17;
    z3(:,i)=z1(:,i)-(i-1)*R12/17;
end
surf(a4,b5,z1);
hold on 
surf(a4,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a4,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b5,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b5,z3);

%% TE_2-R2_2
R22=R22/T;
z1=zeros(18,18)+R22;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R22/17;
    z3(:,i)=z1(:,i)-(i-1)*R22/17;
end
surf(a4,b6,z1);
hold on 
surf(a4,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a4,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b6,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b6,z3);

%% TE_2-TE_3
TE3=TE3/T;
z1=zeros(18,18)+TE3;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE3/17;
    z3(:,i)=z1(:,i)-(i-1)*TE3/17;
end
surf(a4,b7,z1);
hold on 
surf(a4,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a4,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b7,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b7,z3);

%% TE_2-R2_3
R23=R23/T;
z1=zeros(18,18)+R23;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R23/17;
    z3(:,i)=z1(:,i)-(i-1)*R23/17;
end
surf(a4,b9,z1);
hold on 
surf(a4,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a4,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b9,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b9,z3);

%% TE_2-TE_4
TE4=TE4/T;
z1=zeros(18,18)+TE4;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE4/17;
    z3(:,i)=z1(:,i)-(i-1)*TE4/17;
end
surf(a4,b10,z1);
hold on 
surf(a4,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a4,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b10,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b10,z3);

%% TE_2-R2_4
R24=R24/T;
z1=zeros(18,18)+R24;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R24/17;
    z3(:,i)=z1(:,i)-(i-1)*R24/17;
end
surf(a4,b12,z1);
hold on 
surf(a4,b12*0+(12-1)*(D+d),z2);
hold on 
surf(a4,b12*0+(12-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b12,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b12,z3);

%% TE_3
TE1=10^(-2.61355);R11=10^(-3.21175);R21=10^(-2.7142);TE2=10^(-1.51015);R12=10^(-1.423);R22=10^(-1.35875);
TE3=10^(-1.4545);R13=10^(-2.81525);R23=10^(-2.14975);TE4=10^(-0.33995);R24=10^(-2.41495);
T=TE1+R11+R21+TE2+R12+R22+TE3+R13+R23+TE4+R24;
%T=1;

%% TE_3-TE_1
TE1=TE1/T;
z1=zeros(18,18)+TE1;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE1/17;
    z3(:,i)=z1(:,i)-(i-1)*TE1/17;
end
surf(a7,b1,z1);
hold on 
surf(a7,b1*0+(1-1)*(D+d),z2);
hold on 
surf(a7,b1*0+(1-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b1,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b1,z3);

%% TE_3-R1_1
R11=R11/T;
z1=zeros(18,18)+R11;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R11/17;
    z3(:,i)=z1(:,i)-(i-1)*R11/17;
end
surf(a7,b2,z1);
hold on 
surf(a7,b2*0+(2-1)*(D+d),z2);
hold on 
surf(a7,b2*0+(2-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b2,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b2,z3);

%% TE_3-R2_1
R21=R21/T;
z1=zeros(18,18)+R21;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R21/17;
    z3(:,i)=z1(:,i)-(i-1)*R21/17;
end
surf(a7,b3,z1);
hold on 
surf(a7,b3*0+(3-1)*(D+d),z2);
hold on 
surf(a7,b3*0+(3-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b3,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b3,z3);

%% TE_3-TE_2
TE2=TE2/T;
z1=zeros(18,18)+TE2;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE2/17;
    z3(:,i)=z1(:,i)-(i-1)*TE2/17;
end
surf(a7,b4,z1);
hold on 
surf(a7,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a7,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b4,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b4,z3);

%% TE_3-R1_2
R12=R12/T;
z1=zeros(18,18)+R12;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R12/17;
    z3(:,i)=z1(:,i)-(i-1)*R12/17;
end
surf(a7,b5,z1);
hold on 
surf(a7,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a7,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b5,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b5,z3);

%% TE_3-R2_2
R22=R22/T;
z1=zeros(18,18)+R22;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R22/17;
    z3(:,i)=z1(:,i)-(i-1)*R22/17;
end
surf(a7,b6,z1);
hold on 
surf(a7,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a7,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b6,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b6,z3);

%% TE_3-TE_3
TE3=TE3/T;
z1=zeros(18,18)+TE3;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE3/17;
    z3(:,i)=z1(:,i)-(i-1)*TE3/17;
end
surf(a7,b7,z1);
hold on 
surf(a7,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a7,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b7,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b7,z3);

%% TE_3-R1_3
R13=R13/T;
z1=zeros(18,18)+R13;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R13/17;
    z3(:,i)=z1(:,i)-(i-1)*R13/17;
end
surf(a7,b8,z1);
hold on 
surf(a7,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a7,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b8,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b8,z3);

%% TE_3-R2_3
R23=R23/T;
z1=zeros(18,18)+R23;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R23/17;
    z3(:,i)=z1(:,i)-(i-1)*R23/17;
end
surf(a7,b9,z1);
hold on 
surf(a7,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a7,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b9,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b9,z3);

%% TE_3-TE_4
TE4=TE4/T;
z1=zeros(18,18)+TE4;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE4/17;
    z3(:,i)=z1(:,i)-(i-1)*TE4/17;
end
surf(a7,b10,z1);
hold on 
surf(a7,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a7,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b10,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b10,z3);

%% TE_3-R2_4
R24=R24/T;
z1=zeros(18,18)+R24;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R24/17;
    z3(:,i)=z1(:,i)-(i-1)*R24/17;
end
surf(a7,b12,z1);
hold on 
surf(a7,b12*0+(12-1)*(D+d),z2);
hold on 
surf(a7,b12*0+(12-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b12,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b12,z3);

%% TE_4
z4=zeros(12*(D*10+1),10*D+2+1)+0.001;
aa3=(10-1)*(D+d)-0.1:0.1:(10-1)*(D+d)+D+0.1;
surf(aa3,b,z4);

%% R1_1
TE1=10^(-1.5589);R11=10^(-0.0378);R21=10^(-1.84375);TE2=10^(-1.9216);TE3=10^(-1.79345);TE4=10^(-2.2591);
T=TE1+R11+R21+TE2+TE3+TE4;
%T=1;
%% R1_1-TE_1
TE1=TE1/T;
z1=zeros(18,18)+TE1;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE1/17;
    z3(:,i)=z1(:,i)-(i-1)*TE1/17;
end
surf(a2,b1,z1);
hold on 
surf(a2,b1*0,z2);
hold on 
surf(a2,b1*0+(1-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b1,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b1,z3);

%% R1_1-R1_1
R11=R11/T;
z1=zeros(18,18)+R11;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R11/17;
    z3(:,i)=z1(:,i)-(i-1)*R11/17;
end
surf(a2,b2,z1);
hold on 
surf(a2,b2*0+(2-1)*(D+d),z2);
hold on 
surf(a2,b2*0+(2-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b2,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b2,z3);

%% R1_1-R2_1
R21=R21/T;
z1=zeros(18,18)+R21;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R21/17;
    z3(:,i)=z1(:,i)-(i-1)*R21/17;
end
surf(a2,b3,z1);
hold on 
surf(a2,b3*0+(3-1)*(D+d),z2);
hold on 
surf(a2,b3*0+(3-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b3,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b3,z3);

%% R1_1-TE_2
TE2=TE2/T;
z1=zeros(18,18)+TE2;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE2/17;
    z3(:,i)=z1(:,i)-(i-1)*TE2/17;
end
surf(a2,b4,z1);
hold on 
surf(a2,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a2,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b4,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b4,z3);

%% R1_1-TE_3
TE3=TE3/T;
z1=zeros(18,18)+TE3;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE3/17;
    z3(:,i)=z1(:,i)-(i-1)*TE3/17;
end
surf(a2,b7,z1);
hold on 
surf(a2,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a2,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b7,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b7,z3);

%% R1_1-TE_4
TE4=TE4/T;
z1=zeros(18,18)+TE4;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE4/17;
    z3(:,i)=z1(:,i)-(i-1)*TE4/17;
end
surf(a2,b10,z1);
hold on 
surf(a2,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a2,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b10,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b10,z3);

%% R1_2
R11=10^(-2.05875);R21=10^(-1.3833);TE2=10^(-2.00635);R12=10^(-0.2882);R22=10^(-1.22455);TE3=10^(-1.9542);TE4=10^(-1.53285);
T=R11+R21+TE2+R12+R22+TE3+TE4;
%T=1;
%% R1_2-R1_1
R11=R11/T;
z1=zeros(18,18)+R11;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R11/17;
    z3(:,i)=z1(:,i)-(i-1)*R11/17;
end
surf(a5,b2,z1);
hold on 
surf(a5,b2*0+(2-1)*(D+d),z2);
hold on 
surf(a5,b2*0+(2-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b2,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b2,z3);

%% R1_2-R2_1
R21=R21/T;
z1=zeros(18,18)+R21;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R21/17;
    z3(:,i)=z1(:,i)-(i-1)*R21/17;
end
surf(a5,b3,z1);
hold on 
surf(a5,b3*0+(3-1)*(D+d),z2);
hold on 
surf(a5,b3*0+(3-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b3,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b3,z3);

%% R1_2-TE_2
TE2=TE2/T;
z1=zeros(18,18)+TE2;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE2/17;
    z3(:,i)=z1(:,i)-(i-1)*TE2/17;
end
surf(a5,b4,z1);
hold on 
surf(a5,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a5,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b4,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b4,z3);

%% R1_2-R1_2
R12=R12/T;
z1=zeros(18,18)+R12;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R12/17;
    z3(:,i)=z1(:,i)-(i-1)*R12/17;
end
surf(a5,b5,z1);
hold on 
surf(a5,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a5,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b5,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b5,z3);

%% R1_2-R2_2
R22=R22/T;
z1=zeros(18,18)+R22;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R22/17;
    z3(:,i)=z1(:,i)-(i-1)*R22/17;
end
surf(a5,b6,z1);
hold on 
surf(a5,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a5,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b6,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b6,z3);

%% R1_2-TE_3
TE3=TE3/T;
z1=zeros(18,18)+TE3;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE3/17;
    z3(:,i)=z1(:,i)-(i-1)*TE3/17;
end
surf(a5,b7,z1);
hold on 
surf(a5,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a5,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b7,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b7,z3);

%% R1_2-TE_4
TE4=TE4/T;
z1=zeros(18,18)+TE4;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE4/17;
    z3(:,i)=z1(:,i)-(i-1)*TE4/17;
end
surf(a5,b10,z1);
hold on 
surf(a5,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a5,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b10,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b10,z3);

%% R1_3
TE2=10^(-1.8599);R12=10^(-1.86725);R22=10^(-1.4375);TE3=10^(-1.56825);R13=10^(-0.4952);R23=10^(-2.0542);TE4=10^(-1.9193);
T=TE2+R12+R22+TE3+R13+R23+TE4;
%T=1;
%% R1_3-TE_2
TE2=TE2/T;
z1=zeros(18,18)+TE2;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE2/17;
    z3(:,i)=z1(:,i)-(i-1)*TE2/17;
end
surf(a8,b4,z1);
hold on 
surf(a8,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a8,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b4,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b4,z3);

%% R1_3-R1_2
R12=R12/T;
z1=zeros(18,18)+R12;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R12/17;
    z3(:,i)=z1(:,i)-(i-1)*R12/17;
end
surf(a8,b5,z1);
hold on 
surf(a8,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a8,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b5,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b5,z3);

%% R1_3-R2_2
R22=R22/T;
z1=zeros(18,18)+R22;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R22/17;
    z3(:,i)=z1(:,i)-(i-1)*R22/17;
end
surf(a8,b6,z1);
hold on 
surf(a8,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a8,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b6,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b6,z3);

%% R1_3-TE_3
TE3=TE3/T;
z1=zeros(18,18)+TE3;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE3/17;
    z3(:,i)=z1(:,i)-(i-1)*TE3/17;
end
surf(a8,b7,z1);
hold on 
surf(a8,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a8,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b7,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b7,z3);

%% R1_3-R1_3
R13=R13/T;
z1=zeros(18,18)+R13;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R13/17;
    z3(:,i)=z1(:,i)-(i-1)*R13/17;
end
surf(a8,b8,z1);
hold on 
surf(a8,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a8,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b8,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b8,z3);

%% R1_3-R2_3
R23=R23/T;
z1=zeros(18,18)+R23;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R23/17;
    z3(:,i)=z1(:,i)-(i-1)*R23/17;
end
surf(a8,b9,z1);
hold on 
surf(a8,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a8,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b9,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b9,z3);

%% R1_3-TE_4
TE4=TE4/T;
z1=zeros(18,18)+TE4;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE4/17;
    z3(:,i)=z1(:,i)-(i-1)*TE4/17;
end
surf(a8,b10,z1);
hold on 
surf(a8,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a8,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b10,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b10,z3);

%% R1_4
R13=10^(-3.3232);R23=10^(-1.2977);R14=10^(-0.1346);R24=10^(-1.3207);
T=R13+R23+R14+R24;
%T=1;
%% R1_4-R1_3
R13=R13/T;
z1=zeros(18,18)+R13;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R13/17;
    z3(:,i)=z1(:,i)-(i-1)*R13/17;
end
surf(a11,b8,z1);
hold on 
surf(a11,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a11,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a11*0+(11-1)*(D+d),b8,z3);
hold on 
surf(a11*0+(11-1)*(D+d)+D,b8,z3);

%% R1_4-R2_3
R23=R23/T;
z1=zeros(18,18)+R23;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R23/17;
    z3(:,i)=z1(:,i)-(i-1)*R23/17;
end
surf(a11,b9,z1);
hold on 
surf(a11,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a11,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a11*0+(11-1)*(D+d),b9,z3);
hold on 
surf(a11*0+(11-1)*(D+d)+D,b9,z3);

%% R1_4-R1_4
R14=R14/T;
z1=zeros(18,18)+R14;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R14/17;
    z3(:,i)=z1(:,i)-(i-1)*R14/17;
end
surf(a11,b11,z1);
hold on 
surf(a11,b11*0+25,z2);
hold on 
surf(a11,b11*0+27,z2);
hold on 
surf(a11*0+(11-1)*(D+d),b11,z3);
hold on 
surf(a11*0+(11-1)*(D+d)+D,b11,z3);

%% R1_4-R2_4
R24=R24/T;
z1=zeros(18,18)+R24;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R24/17;
    z3(:,i)=z1(:,i)-(i-1)*R24/17;
end
surf(a11,b12,z1);
hold on 
surf(a11,b12*0+(12-1)*(D+d),z2);
hold on 
surf(a11,b12*0+(12-1)*(D+d)+D,z2);
hold on 
surf(a11*0+(11-1)*(D+d),b12,z3);
hold on 
surf(a11*0+(11-1)*(D+d)+D,b12,z3);

%% R2_1
z4=zeros(12*(10*D+1),D*10+2+1)+0.001;
aa3=(3-1)*(D+d)-0.1:0.1:(3-1)*(D+d)+D+0.1;
surf(aa3,b,z4);

%% R2_2
TE1=10^(-1.3489);R11=10^(-1.7147);R21=10^(-0.12625);TE2=10^(-1.7505);R12=10^(-3.28175);R22=10^(-1.2356);TE3=10^(-1.59725);TE4=10^(-2.6589);
T=TE1+R11+R21+TE2+R12+R22+TE3+TE4;
%T=1;
%% R2_2-TE_1
TE1=TE1/T;
z1=zeros(18,18)+TE1;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE1/17;
    z3(:,i)=z1(:,i)-(i-1)*TE1/17;
end
surf(a6,b1,z1);
hold on 
surf(a6,b1*0,z2);
hold on 
surf(a6,b1*0+(1-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b1,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b1,z3);

%% R2_2-R1_1
R11=R11/T;
z1=zeros(18,18)+R11;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R11/17;
    z3(:,i)=z1(:,i)-(i-1)*R11/17;
end
surf(a6,b2,z1);
hold on 
surf(a6,b2*0+(2-1)*(D+d),z2);
hold on 
surf(a6,b2*0+(2-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b2,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b2,z3);

%% R2_2-R2_1
R21=R21/T;
z1=zeros(18,18)+R21;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R21/17;
    z3(:,i)=z1(:,i)-(i-1)*R21/17;
end
surf(a6,b3,z1);
hold on 
surf(a6,b3*0+(3-1)*(D+d),z2);
hold on 
surf(a6,b3*0+(3-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b3,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b3,z3);

%% R2_2-TE_2
TE2=TE2/T;
z1=zeros(18,18)+TE2;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE2/17;
    z3(:,i)=z1(:,i)-(i-1)*TE2/17;
end
surf(a6,b4,z1);
hold on 
surf(a6,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a6,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b4,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b4,z3);

%% R2_2-R1_2
R12=R12/T;
z1=zeros(18,18)+R12;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R12/17;
    z3(:,i)=z1(:,i)-(i-1)*R12/17;
end
surf(a6,b5,z1);
hold on 
surf(a6,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a6,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b5,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b5,z3);

%% R2_2-R2_2
R22=R22/T;
z1=zeros(18,18)+R22;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R22/17;
    z3(:,i)=z1(:,i)-(i-1)*R22/17;
end
surf(a6,b6,z1);
hold on 
surf(a6,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a6,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b6,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b6,z3);

%% R2_2-TE_3
TE3=TE3/T;
z1=zeros(18,18)+TE3;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE3/17;
    z3(:,i)=z1(:,i)-(i-1)*TE3/17;
end
surf(a6,b7,z1);
hold on 
surf(a6,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a6,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b7,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b7,z3);

%% R2_2-TE_4
TE4=TE4/T;
z1=zeros(18,18)+TE4;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE4/17;
    z3(:,i)=z1(:,i)-(i-1)*TE4/17;
end
surf(a6,b10,z1);
hold on 
surf(a6,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a6,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b10,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b10,z3);

%% R2_3
TE2=10^(-1.5836);R12=10^(-1.44935);R22=10^(-0.3536);TE3=10^(-1.7816);R13=10^(-2.1742);R23=10^(-1.5642);TE4=10^(-1.6785);R24=10^(-1.7816);
T=TE2+R12+R22+TE3+R13+R23+TE4+R24;
%T=1;
%% R2_3-TE_2
TE2=TE2/T;
z1=zeros(18,18)+TE2;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE2/17;
    z3(:,i)=z1(:,i)-(i-1)*TE2/17;
end
surf(a9,b4,z1);
hold on 
surf(a9,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a9,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b4,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b4,z3);

%% R2_3-R1_2
R12=R12/T;
z1=zeros(18,18)+R12;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R12/17;
    z3(:,i)=z1(:,i)-(i-1)*R12/17;
end
surf(a9,b5,z1);
hold on 
surf(a9,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a9,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b5,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b5,z3);

%% R2_3-R2_2
R22=R22/T;
z1=zeros(18,18)+R22;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R22/17;
    z3(:,i)=z1(:,i)-(i-1)*R22/17;
end
surf(a9,b6,z1);
hold on 
surf(a9,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a9,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b6,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b6,z3);

%% R2_3-TE_3
TE3=TE3/T;
z1=zeros(18,18)+TE3;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE3/17;
    z3(:,i)=z1(:,i)-(i-1)*TE3/17;
end
surf(a9,b7,z1);
hold on 
surf(a9,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a9,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b7,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b7,z3);

%% R2_3-R1_3
R13=R13/T;
z1=zeros(18,18)+R13;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R13/17;
    z3(:,i)=z1(:,i)-(i-1)*R13/17;
end
surf(a9,b8,z1);
hold on 
surf(a9,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a9,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b8,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b8,z3);

%% R2_3-R2_3
R23=R23/T;
z1=zeros(18,18)+R23;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R23/17;
    z3(:,i)=z1(:,i)-(i-1)*R23/17;
end
surf(a9,b9,z1);
hold on 
surf(a9,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a9,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b9,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b9,z3);

%% R2_3-TE_4
TE4=TE4/T;
z1=zeros(18,18)+TE4;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE4/17;
    z3(:,i)=z1(:,i)-(i-1)*TE4/17;
end
surf(a9,b10,z1);
hold on 
surf(a9,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a9,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b10,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b10,z3);

%% R2_3-R2_4
R24=R24/T;
z1=zeros(18,18)+R24;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R24/17;
    z3(:,i)=z1(:,i)-(i-1)*R24/17;
end
surf(a9,b12,z1);
hold on 
surf(a9,b12*0+(12-1)*(D+d),z2);
hold on 
surf(a9,b12*0+(12-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b12,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b12,z3);

%% R2_4
TE2=10^(-2.9392);R22=10^(-2.371);TE3=10^(-2.30015);R13=10^(-1.524);R23=10^(-0.3312);TE4=10^(-2.1365);R14=10^(-2.1648);R24=10^(-1.198);
T=TE2+R22+TE3+R13+R23+TE4+R14+R24;
%T=1;
%% R2_4-TE_2
TE2=TE2/T;
z1=zeros(18,18)+TE2;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE2/17;
    z3(:,i)=z1(:,i)-(i-1)*TE2/17;
end
surf(a12,b4,z1);
hold on 
surf(a12,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a12,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a12*0+(12-1)*(D+d),b4,z3);
hold on 
surf(a12*0+(12-1)*(D+d)+D,b4,z3);

%% R2_4-R2_2
R22=R22/T;
z1=zeros(18,18)+R22;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R22/17;
    z3(:,i)=z1(:,i)-(i-1)*R22/17;
end
surf(a12,b6,z1);
hold on 
surf(a12,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a12,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a12*0+(12-1)*(D+d),b6,z3);
hold on 
surf(a12*0+(12-1)*(D+d)+D,b6,z3);

%% R2_4-TE_3
TE3=TE3/T;
z1=zeros(18,18)+TE3;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE3/17;
    z3(:,i)=z1(:,i)-(i-1)*TE3/17;
end
surf(a12,b7,z1);
hold on 
surf(a12,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a12,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a12*0+(12-1)*(D+d),b7,z3);
hold on 
surf(a12*0+(12-1)*(D+d)+D,b7,z3);

%% R2_4-R1_3
R13=R13/T;
z1=zeros(18,18)+R13;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R13/17;
    z3(:,i)=z1(:,i)-(i-1)*R13/17;
end
surf(a12,b8,z1);
hold on 
surf(a12,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a12,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a12*0+(12-1)*(D+d),b8,z3);
hold on 
surf(a12*0+(12-1)*(D+d)+D,b8,z3);

%% R2_4-R2_3
R23=R23/T;
z1=zeros(18,18)+R23;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R23/17;
    z3(:,i)=z1(:,i)-(i-1)*R23/17;
end
surf(a12,b9,z1);
hold on 
surf(a12,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a12,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a12*0+(12-1)*(D+d),b9,z3);
hold on 
surf(a12*0+(12-1)*(D+d)+D,b9,z3);

%% R2_4-TE_4
TE4=TE4/T;
z1=zeros(18,18)+TE4;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*TE4/17;
    z3(:,i)=z1(:,i)-(i-1)*TE4/17;
end
surf(a12,b10,z1);
hold on 
surf(a12,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a12,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a12*0+(12-1)*(D+d),b10,z3);
hold on 
surf(a12*0+(12-1)*(D+d)+D,b10,z3);

%% R2_4-R1_4
R14=R14/T;
z1=zeros(18,18)+R14;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R14/17;
    z3(:,i)=z1(:,i)-(i-1)*R14/17;
end
surf(a12,b11,z1);
hold on 
surf(a12,b11*0+25,z2);
hold on 
surf(a12,b11*0+27,z2);
hold on 
surf(a12*0+(12-1)*(D+d),b11,z3);
hold on 
surf(a12*0+(12-1)*(D+d)+D,b11,z3);

%% R2_4-R2_4
R24=R24/T;
z1=zeros(18,18)+R24;
for i=1:1:18
    z2(i,:)=z1(i,:)-(i-1)*R24/17;
    z3(:,i)=z1(:,i)-(i-1)*R24/17;
end
surf(a12,b12,z1);
hold on 
surf(a12,b12*0+(12-1)*(D+d),z2);
hold on 
surf(a12,b12*0+(12-1)*(D+d)+D,z2);
hold on 
surf(a12*0+(12-1)*(D+d),b12,z3);
hold on 
surf(a12*0+(12-1)*(D+d)+D,b12,z3);

xlim([0,30]);
ylim([0,30]);
zlim([0,1]);
shading flat

p1=0:0.1:(12-1)*(D+d)+D;
q1=(12-1)*(D+d)+D+0*p1;
z1=1+0*p1;
plot3(p1,q1,z1,'color',[0.75 0.75 0.75],'linewidth',1);

q2=0.1:0.1:(12-1)*(D+d)+D;
p2=(12-1)*(D+d)+D+0*q2;
z2=1+0*q2;
plot3(p2,q2,z2,'color',[0.75 0.75 0.75],'linewidth',1);

z3=0:0.1:1;
p3=0+0*z3;
q3=(12-1)*(D+d)+D+0*z3;
p4=(12-1)*(D+d)+D+0*z3;
q4=(12-1)*(D+d)+D+0*z3;
p5=(12-1)*(D+d)+D+0*z3;
q5=0.1+0*z3;
plot3(p3,q3,z3,'color',[0.75 0.75 0.75],'linewidth',1);
hold on
plot3(p4,q4,z3,'color',[0.75 0.75 0.75],'linewidth',1);
hold on
plot3(p5,q5,z3,'color',[0.75 0.75 0.75],'linewidth',1);

colorbar; colormap(hot);
clim([0 1]);
%view(-23.0642,67.2)
view(-64.8131,76.8)

set(gca,'xcolor',[1 1 1]);
set(gca,'ycolor',[1 1 1]);
set(gca,'zcolor',[1 1 1]);
set(gcf,'color',[1 1 1]);

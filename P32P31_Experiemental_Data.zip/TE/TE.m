for i=1:1:12
    a1=0:0.1:2;
    aa = ['a',num2str(i),'=a1+2.5*(i-1);'];
    eval(aa);
    b1=0:0.1:2;
    bb = ['b',num2str(i),'=b1+2.5*(i-1);'];
    eval(bb);
end
a=[a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12];
b=[b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12];
z1=zeros(21,21)+0.001;
figure(1)
for i=1:1:12
    cc=['a',num2str(i)];
    c=eval(cc);
    for j=1:1:12
        dd=['b',num2str(j)];
        d=eval(dd);
        surf(c,d,z1);
        hold on
    end
end

%% TE_1
TE1=10^(-1.4436);R21=10^(-1.48225);TE2=10^(-0.1601);R12=10^(-3.21485);TE3=10^(-1.58725);TE4=10^(-1.7355);
T=TE1+R21+TE2+R12+TE3+TE4;
%T=1;

%% TE_1-TE_1
TE1=TE1/T;
z1=zeros(21,21)+TE1;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE1/20;
    z3(:,i)=z1(:,i)-(i-1)*TE1/20;
end
surf(a1,b1,z1);
hold on 
surf(a1,b1*0+0,z2);
hold on 
surf(a1,b1*0+2,z2);
hold on 
surf(a1*0+0,b1,z3);
hold on 
surf(a1*0+2,b1,z3);

%% TE_1-R2_1
R21=R21/T;
z1=zeros(21,21)+R21;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R21/20;
    z3(:,i)=z1(:,i)-(i-1)*R21/20;
end
surf(a1,b3,z1);
hold on 
surf(a1,b3*0+5,z2);
hold on 
surf(a1,b3*0+7,z2);
hold on 
surf(a1*0+0,b3,z3);
hold on 
surf(a1*0+2,b3,z3);

%% TE_1-TE_2
TE2=TE2/T;
z1=zeros(21,21)+TE2;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE2/20;
    z3(:,i)=z1(:,i)-(i-1)*TE2/20;
end
surf(a1,b4,z1);
hold on 
surf(a1,b4*0+7.5,z2);
hold on 
surf(a1,b4*0+9.5,z2);
hold on 
surf(a1*0+0,b4,z3);
hold on 
surf(a1*0+2,b4,z3);

%% TE_1-R1_2
R12=R12/T;
z1=zeros(21,21)+R12;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R12/20;
    z3(:,i)=z1(:,i)-(i-1)*R12/20;
end
surf(a1,b5,z1);
hold on 
surf(a1,b5*0+10,z2);
hold on 
surf(a1,b5*0+12,z2);
hold on 
surf(a1*0+0,b5,z3);
hold on 
surf(a1*0+2,b5,z3);

%% TE_1-TE_3
TE3=TE3/T;
z1=zeros(21,21)+TE3;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE3/20;
    z3(:,i)=z1(:,i)-(i-1)*TE3/20;
end
surf(a1,b7,z1);
hold on 
surf(a1,b7*0+15,z2);
hold on 
surf(a1,b7*0+17,z2);
hold on 
surf(a1*0+0,b7,z3);
hold on 
surf(a1*0+2,b7,z3);

%% TE_1-TE_4
TE4=TE4/T;
z1=zeros(21,21)+TE4;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE4/20;
    z3(:,i)=z1(:,i)-(i-1)*TE4/20;
end
surf(a1,b10,z1);
hold on 
surf(a1,b10*0+22.5,z2);
hold on 
surf(a1,b10*0+24.5,z2);
hold on 
surf(a1*0+0,b10,z3);
hold on 
surf(a1*0+2,b10,z3);

%% TE_2
TE1=10^(-2.0539);R11=10^(-1.524);R21=10^(-1.79175);TE2=10^(-1.4328);R12=10^(-1.46135);R22=10^(-1.5056);
TE3=10^(-0.20945);R23=10^(-4.0098);TE4=10^(-1.4271);R24=10^(-2.693);
T=TE1+R11+R21+TE2+R12+R22+TE3+R23+TE4+R24;
%T=1;

%% TE_2-TE_1
TE1=TE1/T;
z1=zeros(21,21)+TE1;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE1/20;
    z3(:,i)=z1(:,i)-(i-1)*TE1/20;
end
surf(a4,b1,z1);
hold on 
surf(a4,b1*0+0,z2);
hold on 
surf(a4,b1*0+2,z2);
hold on 
surf(a4*0+7.5,b1,z3);
hold on 
surf(a4*0+9.5,b1,z3);

%% TE_2-R1_1
R11=R11/T;
z1=zeros(21,21)+R11;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R11/20;
    z3(:,i)=z1(:,i)-(i-1)*R11/20;
end
surf(a4,b2,z1);
hold on 
surf(a4,b2*0+2.5,z2);
hold on 
surf(a4,b2*0+4.5,z2);
hold on 
surf(a4*0+7.5,b2,z3);
hold on 
surf(a4*0+9.5,b2,z3);

%% TE_2-R2_1
R21=R21/T;
z1=zeros(21,21)+R21;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R21/20;
    z3(:,i)=z1(:,i)-(i-1)*R21/20;
end
surf(a4,b3,z1);
hold on 
surf(a4,b3*0+5,z2);
hold on 
surf(a4,b3*0+7,z2);
hold on 
surf(a4*0+7.5,b3,z3);
hold on 
surf(a4*0+9.5,b3,z3);

%% TE_2-TE_2
TE2=TE2/T;
z1=zeros(21,21)+TE2;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE2/20;
    z3(:,i)=z1(:,i)-(i-1)*TE2/20;
end
surf(a4,b4,z1);
hold on 
surf(a4,b4*0+7.5,z2);
hold on 
surf(a4,b4*0+9.5,z2);
hold on 
surf(a4*0+7.5,b4,z3);
hold on 
surf(a4*0+9.5,b4,z3);

%% TE_2-R1_2
R12=R12/T;
z1=zeros(21,21)+R12;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R12/20;
    z3(:,i)=z1(:,i)-(i-1)*R12/20;
end
surf(a4,b5,z1);
hold on 
surf(a4,b5*0+10,z2);
hold on 
surf(a4,b5*0+12,z2);
hold on 
surf(a4*0+7.5,b5,z3);
hold on 
surf(a4*0+9.5,b5,z3);

%% TE_2-R2_2
R22=R22/T;
z1=zeros(21,21)+R22;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R22/20;
    z3(:,i)=z1(:,i)-(i-1)*R22/20;
end
surf(a4,b6,z1);
hold on 
surf(a4,b6*0+12.5,z2);
hold on 
surf(a4,b6*0+14.5,z2);
hold on 
surf(a4*0+7.5,b6,z3);
hold on 
surf(a4*0+9.5,b6,z3);

%% TE_2-TE_3
TE3=TE3/T;
z1=zeros(21,21)+TE3;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE3/20;
    z3(:,i)=z1(:,i)-(i-1)*TE3/20;
end
surf(a4,b7,z1);
hold on 
surf(a4,b7*0+15,z2);
hold on 
surf(a4,b7*0+17,z2);
hold on 
surf(a4*0+7.5,b7,z3);
hold on 
surf(a4*0+9.5,b7,z3);

%% TE_2-R2_3
R23=R23/T;
z1=zeros(21,21)+R23;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R23/20;
    z3(:,i)=z1(:,i)-(i-1)*R23/20;
end
surf(a4,b9,z1);
hold on 
surf(a4,b9*0+20,z2);
hold on 
surf(a4,b9*0+22,z2);
hold on 
surf(a4*0+7.5,b9,z3);
hold on 
surf(a4*0+9.5,b9,z3);

%% TE_2-TE_4
TE4=TE4/T;
z1=zeros(21,21)+TE4;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE4/20;
    z3(:,i)=z1(:,i)-(i-1)*TE4/20;
end
surf(a4,b10,z1);
hold on 
surf(a4,b10*0+22.5,z2);
hold on 
surf(a4,b10*0+24.5,z2);
hold on 
surf(a4*0+7.5,b10,z3);
hold on 
surf(a4*0+9.5,b10,z3);

%% TE_2-R2_4
R24=R24/T;
z1=zeros(21,21)+R24;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R24/20;
    z3(:,i)=z1(:,i)-(i-1)*R24/20;
end
surf(a4,b12,z1);
hold on 
surf(a4,b12*0+27.5,z2);
hold on 
surf(a4,b12*0+29.5,z2);
hold on 
surf(a4*0+7.5,b12,z3);
hold on 
surf(a4*0+9.5,b12,z3);

%% TE_3
TE1=10^(-2.61355);R11=10^(-3.21175);R21=10^(-2.7142);TE2=10^(-1.51015);R12=10^(-1.423);R22=10^(-1.35875);
TE3=10^(-1.4545);R13=10^(-2.81525);R23=10^(-2.14975);TE4=10^(-0.33995);R24=10^(-2.41495);
T=TE1+R11+R21+TE2+R12+R22+TE3+R13+R23+TE4+R24;
%T=1;

%% TE_3-TE_1
TE1=TE1/T;
z1=zeros(21,21)+TE1;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE1/20;
    z3(:,i)=z1(:,i)-(i-1)*TE1/20;
end
surf(a7,b1,z1);
hold on 
surf(a7,b1*0+0,z2);
hold on 
surf(a7,b1*0+2,z2);
hold on 
surf(a7*0+15,b1,z3);
hold on 
surf(a7*0+17,b1,z3);

%% TE_3-R1_1
R11=R11/T;
z1=zeros(21,21)+R11;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R11/20;
    z3(:,i)=z1(:,i)-(i-1)*R11/20;
end
surf(a7,b2,z1);
hold on 
surf(a7,b2*0+2.5,z2);
hold on 
surf(a7,b2*0+4.5,z2);
hold on 
surf(a7*0+15,b2,z3);
hold on 
surf(a7*0+17,b2,z3);

%% TE_3-R2_1
R21=R21/T;
z1=zeros(21,21)+R21;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R21/20;
    z3(:,i)=z1(:,i)-(i-1)*R21/20;
end
surf(a7,b3,z1);
hold on 
surf(a7,b3*0+5,z2);
hold on 
surf(a7,b3*0+7,z2);
hold on 
surf(a7*0+15,b3,z3);
hold on 
surf(a7*0+17,b3,z3);

%% TE_3-TE_2
TE2=TE2/T;
z1=zeros(21,21)+TE2;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE2/20;
    z3(:,i)=z1(:,i)-(i-1)*TE2/20;
end
surf(a7,b4,z1);
hold on 
surf(a7,b4*0+7.5,z2);
hold on 
surf(a7,b4*0+9.5,z2);
hold on 
surf(a7*0+15,b4,z3);
hold on 
surf(a7*0+17,b4,z3);

%% TE_3-R1_2
R12=R12/T;
z1=zeros(21,21)+R12;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R12/20;
    z3(:,i)=z1(:,i)-(i-1)*R12/20;
end
surf(a7,b5,z1);
hold on 
surf(a7,b5*0+10,z2);
hold on 
surf(a7,b5*0+12,z2);
hold on 
surf(a7*0+15,b5,z3);
hold on 
surf(a7*0+17,b5,z3);

%% TE_3-R2_2
R22=R22/T;
z1=zeros(21,21)+R22;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R22/20;
    z3(:,i)=z1(:,i)-(i-1)*R22/20;
end
surf(a7,b6,z1);
hold on 
surf(a7,b6*0+12.5,z2);
hold on 
surf(a7,b6*0+14.5,z2);
hold on 
surf(a7*0+15,b6,z3);
hold on 
surf(a7*0+17,b6,z3);

%% TE_3-TE_3
TE3=TE3/T;
z1=zeros(21,21)+TE3;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE3/20;
    z3(:,i)=z1(:,i)-(i-1)*TE3/20;
end
surf(a7,b7,z1);
hold on 
surf(a7,b7*0+15,z2);
hold on 
surf(a7,b7*0+17,z2);
hold on 
surf(a7*0+15,b7,z3);
hold on 
surf(a7*0+17,b7,z3);

%% TE_3-R1_3
R13=R13/T;
z1=zeros(21,21)+R13;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R13/20;
    z3(:,i)=z1(:,i)-(i-1)*R13/20;
end
surf(a7,b8,z1);
hold on 
surf(a7,b8*0+17.5,z2);
hold on 
surf(a7,b8*0+19.5,z2);
hold on 
surf(a7*0+15,b8,z3);
hold on 
surf(a7*0+17,b8,z3);

%% TE_3-R2_3
R23=R23/T;
z1=zeros(21,21)+R23;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R23/20;
    z3(:,i)=z1(:,i)-(i-1)*R23/20;
end
surf(a7,b9,z1);
hold on 
surf(a7,b9*0+20,z2);
hold on 
surf(a7,b9*0+22,z2);
hold on 
surf(a7*0+15,b9,z3);
hold on 
surf(a7*0+17,b9,z3);

%% TE_3-TE_4
TE4=TE4/T;
z1=zeros(21,21)+TE4;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE4/20;
    z3(:,i)=z1(:,i)-(i-1)*TE4/20;
end
surf(a7,b10,z1);
hold on 
surf(a7,b10*0+22.5,z2);
hold on 
surf(a7,b10*0+24.5,z2);
hold on 
surf(a7*0+15,b10,z3);
hold on 
surf(a7*0+17,b10,z3);

%% TE_3-R2_4
R24=R24/T;
z1=zeros(21,21)+R24;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R24/20;
    z3(:,i)=z1(:,i)-(i-1)*R24/20;
end
surf(a7,b12,z1);
hold on 
surf(a7,b12*0+27.5,z2);
hold on 
surf(a7,b12*0+29.5,z2);
hold on 
surf(a7*0+15,b12,z3);
hold on 
surf(a7*0+17,b12,z3);

%% TE_4
z4=zeros(252,27)+0.001;
aa3=22.2:0.1:24.8;
surf(aa3,b,z4);

xlim([0,30]);
ylim([0,30]);
zlim([0,1]);
shading flat

view(-45,60)



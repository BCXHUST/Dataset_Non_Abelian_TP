N=501;

%num='13';

ss=['1-2-3-32-21-1';'1-2-3-32-22-1';'1-2-3-32-23-1';'1-2-3-32-31-1';'1-2-3-32-32-1';'1-2-3-32-33-1';'1-2-3-32-41-1'];

for nn=1:1:7
fid = fopen([ss(nn,:),'.csv'], 'r');                                          
symble=0;
D1=zeros(1,N);
D2=zeros(1,N);
while ~feof(fid)
    tline=fgetl(fid);
    if ~isempty(tline)
        if symble==0
            if tline(2)=='['
                symble=symble+1;
            end
        elseif symble>0
            data=textscan(tline,'%f,%f');
            data=cell2mat(data);
            D1(symble)=data(1); %波长
            D2(symble)=data(2); %数据
            symble=symble+1;
            clear data
        end
    end
end
fclose(fid);

sss=['TE2';'R12';'R22';'TE3';'R13';'R23';'TE4'];
eval(['a',sss(nn,:),'=D2;']);
end
l=D1; 
figure(1);
hold on
plot(l,aTE2-s2243-s1142);
plot(l,aR12-s2243-s2242);
plot(l,aR22-s2243-s3342);
plot(l,aTE3-s2243-s1143);
plot(l,aR13-s2243-s2243,'color',[0,0,0]);
plot(l,aR23-s2243-s3343);
plot(l,aTE4-s2243-s1144);
%legend('TE2','R12','R22','TE3','R13','R23','TE4');
axis([1540,1560,-50,5]);
%axis([1550,1560,-50,10]);
% plot(lambda,10*log10(TTT43));
% hold on;
% plot(lambda,10*log10(TTT44));
% hold on;
% plot(lambda,10*log10(TTT44),'--');
% hold on;
% plot(lambda,10*log10(TTT34));
% axis([1400,1700,-50,0]);

%title('TE输入');
%figure(2);
%hold on
%plot(l,a23-s1-s2);
%plot(l,a24-s2-s2);
%plot(l,a42-s1-s2);
%plot(l,a41-s2-s2);
%title('TM输入');
% axis([1530,1570,-50,0]);
% plot(lambda,10*log10(TTT43));
% hold on;
% plot(lambda,10*log10(TTT33));
% hold on;
% plot(lambda,10*log10(TTT33),'--');
% hold on;
% plot(lambda,10*log10(TTT34));
% hold on;





for i=1:1:12
    a1=0:0.1:2;
    aa = ['a',num2str(i),'=a1+2.5*(i-1);'];
    eval(aa);
    b1=0:0.1:2;
    bb = ['b',num2str(i),'=b1+2.5*(i-1);'];
    eval(bb);
end
a=[a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12];
b=[b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12];
z1=zeros(21,21)+0.001;
figure(1)
for i=1:1:12
    cc=['a',num2str(i)];
    c=eval(cc);
    for j=1:1:12
        dd=['b',num2str(j)];
        d=eval(dd);
        surf(c,d,z1);
        hold on
    end
end

%% R1_1
TE1=10^(-1.5589);R11=10^(-0.0378);R21=10^(-1.84375);TE2=10^(-1.9216);TE3=10^(-1.79345);TE4=10^(-2.2591);
T=TE1+R11+R21+TE2+TE3+TE4;
%T=1;
%% R1_1-TE_1
TE1=TE1/T;
z1=zeros(21,21)+TE1;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE1/20;
    z3(:,i)=z1(:,i)-(i-1)*TE1/20;
end
surf(a2,b1,z1);
hold on 
surf(a2,b1*0,z2);
hold on 
surf(a2,b1*0+2,z2);
hold on 
surf(a2*0+2.5,b1,z3);
hold on 
surf(a2*0+4.5,b1,z3);

%% R1_1-R1_1
R11=R11/T;
z1=zeros(21,21)+R11;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R11/20;
    z3(:,i)=z1(:,i)-(i-1)*R11/20;
end
surf(a2,b2,z1);
hold on 
surf(a2,b2*0+2.5,z2);
hold on 
surf(a2,b2*0+4.5,z2);
hold on 
surf(a2*0+2.5,b2,z3);
hold on 
surf(a2*0+4.5,b2,z3);

%% R1_1-R2_1
R21=R21/T;
z1=zeros(21,21)+R21;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R21/20;
    z3(:,i)=z1(:,i)-(i-1)*R21/20;
end
surf(a2,b3,z1);
hold on 
surf(a2,b3*0+5,z2);
hold on 
surf(a2,b3*0+7,z2);
hold on 
surf(a2*0+2.5,b3,z3);
hold on 
surf(a2*0+4.5,b3,z3);

%% R1_1-TE_2
TE2=TE2/T;
z1=zeros(21,21)+TE2;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE2/20;
    z3(:,i)=z1(:,i)-(i-1)*TE2/20;
end
surf(a2,b4,z1);
hold on 
surf(a2,b4*0+7.5,z2);
hold on 
surf(a2,b4*0+9.5,z2);
hold on 
surf(a2*0+2.5,b4,z3);
hold on 
surf(a2*0+4.5,b4,z3);

%% R1_1-TE_3
TE3=TE3/T;
z1=zeros(21,21)+TE3;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE3/20;
    z3(:,i)=z1(:,i)-(i-1)*TE3/20;
end
surf(a2,b7,z1);
hold on 
surf(a2,b7*0+15,z2);
hold on 
surf(a2,b7*0+17,z2);
hold on 
surf(a2*0+2.5,b7,z3);
hold on 
surf(a2*0+4.5,b7,z3);

%% R1_1-TE_4
TE4=TE4/T;
z1=zeros(21,21)+TE4;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE4/20;
    z3(:,i)=z1(:,i)-(i-1)*TE4/20;
end
surf(a2,b10,z1);
hold on 
surf(a2,b10*0+22.5,z2);
hold on 
surf(a2,b10*0+24.5,z2);
hold on 
surf(a2*0+2.5,b10,z3);
hold on 
surf(a2*0+4.5,b10,z3);

%% R1_2
R11=10^(-2.05875);R21=10^(-1.3833);TE2=10^(-2.00635);R12=10^(-0.2882);R22=10^(-1.22455);TE3=10^(-1.9542);TE4=10^(-1.53285);
T=R11+R21+TE2+R12+R22+TE3+TE4;
%T=1;
%% R1_2-R1_1
R11=R11/T;
z1=zeros(21,21)+R11;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R11/20;
    z3(:,i)=z1(:,i)-(i-1)*R11/20;
end
surf(a5,b2,z1);
hold on 
surf(a5,b2*0+2.5,z2);
hold on 
surf(a5,b2*0+4.5,z2);
hold on 
surf(a5*0+10,b2,z3);
hold on 
surf(a5*0+12,b2,z3);

%% R1_2-R2_1
R21=R21/T;
z1=zeros(21,21)+R21;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R21/20;
    z3(:,i)=z1(:,i)-(i-1)*R21/20;
end
surf(a5,b3,z1);
hold on 
surf(a5,b3*0+5,z2);
hold on 
surf(a5,b3*0+7,z2);
hold on 
surf(a5*0+10,b3,z3);
hold on 
surf(a5*0+12,b3,z3);

%% R1_2-TE_2
TE2=TE2/T;
z1=zeros(21,21)+TE2;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE2/20;
    z3(:,i)=z1(:,i)-(i-1)*TE2/20;
end
surf(a5,b4,z1);
hold on 
surf(a5,b4*0+7.5,z2);
hold on 
surf(a5,b4*0+9.5,z2);
hold on 
surf(a5*0+10,b4,z3);
hold on 
surf(a5*0+12,b4,z3);

%% R1_2-R1_2
R12=R12/T;
z1=zeros(21,21)+R12;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R12/20;
    z3(:,i)=z1(:,i)-(i-1)*R12/20;
end
surf(a5,b5,z1);
hold on 
surf(a5,b5*0+10,z2);
hold on 
surf(a5,b5*0+12,z2);
hold on 
surf(a5*0+10,b5,z3);
hold on 
surf(a5*0+12,b5,z3);

%% R1_2-R2_2
R22=R22/T;
z1=zeros(21,21)+R22;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R22/20;
    z3(:,i)=z1(:,i)-(i-1)*R22/20;
end
surf(a5,b6,z1);
hold on 
surf(a5,b6*0+12.5,z2);
hold on 
surf(a5,b6*0+14.5,z2);
hold on 
surf(a5*0+10,b6,z3);
hold on 
surf(a5*0+12,b6,z3);

%% R1_2-TE_3
TE3=TE3/T;
z1=zeros(21,21)+TE3;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE3/20;
    z3(:,i)=z1(:,i)-(i-1)*TE3/20;
end
surf(a5,b7,z1);
hold on 
surf(a5,b7*0+15,z2);
hold on 
surf(a5,b7*0+17,z2);
hold on 
surf(a5*0+10,b7,z3);
hold on 
surf(a5*0+12,b7,z3);

%% R1_2-TE_4
TE4=TE4/T;
z1=zeros(21,21)+TE4;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE4/20;
    z3(:,i)=z1(:,i)-(i-1)*TE4/20;
end
surf(a5,b10,z1);
hold on 
surf(a5,b10*0+22.5,z2);
hold on 
surf(a5,b10*0+24.5,z2);
hold on 
surf(a5*0+10,b10,z3);
hold on 
surf(a5*0+12,b10,z3);

%% R1_3
TE2=10^(-1.8599);R12=10^(-1.86725);R22=10^(-1.4375);TE3=10^(-1.56825);R13=10^(-0.4952);R23=10^(-2.0542);TE4=10^(-1.9193);
T=TE2+R12+R22+TE3+R13+R23+TE4;
%T=1;
%% R1_3-TE_2
TE2=TE2/T;
z1=zeros(21,21)+TE2;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE2/20;
    z3(:,i)=z1(:,i)-(i-1)*TE2/20;
end
surf(a8,b4,z1);
hold on 
surf(a8,b4*0+7.5,z2);
hold on 
surf(a8,b4*0+9.5,z2);
hold on 
surf(a8*0+17.5,b4,z3);
hold on 
surf(a8*0+19.5,b4,z3);

%% R1_3-R1_2
R12=R12/T;
z1=zeros(21,21)+R12;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R12/20;
    z3(:,i)=z1(:,i)-(i-1)*R12/20;
end
surf(a8,b5,z1);
hold on 
surf(a8,b5*0+10,z2);
hold on 
surf(a8,b5*0+12,z2);
hold on 
surf(a8*0+17.5,b5,z3);
hold on 
surf(a8*0+19.5,b5,z3);

%% R1_3-R2_2
R22=R22/T;
z1=zeros(21,21)+R22;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R22/20;
    z3(:,i)=z1(:,i)-(i-1)*R22/20;
end
surf(a8,b6,z1);
hold on 
surf(a8,b6*0+12.5,z2);
hold on 
surf(a8,b6*0+14.5,z2);
hold on 
surf(a8*0+17.5,b6,z3);
hold on 
surf(a8*0+19.5,b6,z3);

%% R1_3-TE_3
TE3=TE3/T;
z1=zeros(21,21)+TE3;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE3/20;
    z3(:,i)=z1(:,i)-(i-1)*TE3/20;
end
surf(a8,b7,z1);
hold on 
surf(a8,b7*0+15,z2);
hold on 
surf(a8,b7*0+17,z2);
hold on 
surf(a8*0+17.5,b7,z3);
hold on 
surf(a8*0+19.5,b7,z3);

%% R1_3-R1_3
R13=R13/T;
z1=zeros(21,21)+R13;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R13/20;
    z3(:,i)=z1(:,i)-(i-1)*R13/20;
end
surf(a8,b8,z1);
hold on 
surf(a8,b8*0+17.5,z2);
hold on 
surf(a8,b8*0+19.5,z2);
hold on 
surf(a8*0+17.5,b8,z3);
hold on 
surf(a8*0+19.5,b8,z3);

%% R1_3-R2_3
R23=R23/T;
z1=zeros(21,21)+R23;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R23/20;
    z3(:,i)=z1(:,i)-(i-1)*R23/20;
end
surf(a8,b9,z1);
hold on 
surf(a8,b9*0+20,z2);
hold on 
surf(a8,b9*0+22,z2);
hold on 
surf(a8*0+17.5,b9,z3);
hold on 
surf(a8*0+19.5,b9,z3);

%% R1_3-TE_4
TE4=TE4/T;
z1=zeros(21,21)+TE4;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*TE4/20;
    z3(:,i)=z1(:,i)-(i-1)*TE4/20;
end
surf(a8,b10,z1);
hold on 
surf(a8,b10*0+22.5,z2);
hold on 
surf(a8,b10*0+24.5,z2);
hold on 
surf(a8*0+17.5,b10,z3);
hold on 
surf(a8*0+19.5,b10,z3);

%% R1_4
R13=10^(-3.3232);R23=10^(-1.2977);R14=10^(-0.1346);R24=10^(-1.3207);
T=R13+R23+R14+R24;
%T=1;
%% R1_4-R1_3
R13=R13/T;
z1=zeros(21,21)+R13;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R13/20;
    z3(:,i)=z1(:,i)-(i-1)*R13/20;
end
surf(a11,b8,z1);
hold on 
surf(a11,b8*0+17.5,z2);
hold on 
surf(a11,b8*0+19.5,z2);
hold on 
surf(a11*0+25,b8,z3);
hold on 
surf(a11*0+27,b8,z3);

%% R1_4-R2_3
R23=R23/T;
z1=zeros(21,21)+R23;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R23/20;
    z3(:,i)=z1(:,i)-(i-1)*R23/20;
end
surf(a11,b9,z1);
hold on 
surf(a11,b9*0+20,z2);
hold on 
surf(a11,b9*0+22,z2);
hold on 
surf(a11*0+25,b9,z3);
hold on 
surf(a11*0+27,b9,z3);

%% R1_4-R1_4
R14=R14/T;
z1=zeros(21,21)+R14;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R14/20;
    z3(:,i)=z1(:,i)-(i-1)*R14/20;
end
surf(a11,b11,z1);
hold on 
surf(a11,b11*0+25,z2);
hold on 
surf(a11,b11*0+27,z2);
hold on 
surf(a11*0+25,b11,z3);
hold on 
surf(a11*0+27,b11,z3);

%% R1_4-R2_4
R24=R24/T;
z1=zeros(21,21)+R24;
for i=1:1:21
    z2(i,:)=z1(i,:)-(i-1)*R24/20;
    z3(:,i)=z1(:,i)-(i-1)*R24/20;
end
surf(a11,b12,z1);
hold on 
surf(a11,b12*0+27.5,z2);
hold on 
surf(a11,b12*0+29.5,z2);
hold on 
surf(a11*0+25,b12,z3);
hold on 
surf(a11*0+27,b12,z3);


xlim([0,30]);
ylim([0,30]);
zlim([0,1]);
shading flat

view(-45,60)



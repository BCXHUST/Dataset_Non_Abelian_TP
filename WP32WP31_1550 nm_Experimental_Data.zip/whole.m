D=1.7;d=0.8;%D为柱子宽度，d为柱子间距

for i=1:1:12
    a1=0:0.1:D;%每个柱子的宽度
    aa = ['a',num2str(i),'=a1+(D+d)*(i-1);'];
    eval(aa);
    b1=0:0.1:D;%每个柱子的宽度
    bb = ['b',num2str(i),'=b1+(D+d)*(i-1);'];
    eval(bb);
end
a=[a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12];
b=[b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12];
z1=zeros(1+D*10,1+D*10)+0.001;%零矩阵行列为柱子宽度+1
z2=zeros(1+D*10,1+D*10)+0.001;
z3=zeros(1+D*10,1+D*10)+0.001;
figure(1)
for i=1:1:12
    cc=['a',num2str(i)];
    c=eval(cc);
    for j=1:1:12
        ee=['b',num2str(j)];
        e=eval(ee);
        surf(c,e,z1);
        hold on
    end
end

%% 1
%% 1_1
T11=10^(-2.9603);T12=10^(-0.85065);
T21=10^(-2.6871);T22=10^(-3.5443);
T31=10^(-3.1715);
T=T11+T12+T21+T22+T31;
%T=1;
%% 1_1-11
T11=T11/T;
z1=zeros(1+D*10,1+D*10)+T11;
for i=1:1:1+D*10 %i为1至零矩阵行列数
    z2(i,:)=z1(i,:)-(i-1)*T11/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T11/(D*10);
end
surf(a1,b1,z1);
hold on 
surf(a1,b1*0+(1-1)*(D+d),z2);
hold on 
surf(a1,b1*0+(1-1)*(D+d)+D,z2);
hold on 
surf(a1*0+(1-1)*(D+d),b1,z3);
hold on 
surf(a1*0+(1-1)*(D+d)+D,b1,z3);

%% 1_1-12
T12=T12/T;
z1=zeros(1+D*10,1+D*10)+T12;
for i=1:1:1+D*10
    z2(i,:)=z1(i,:)-(i-1)*T12/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T12/(D*10);
end
surf(a1,b4,z1);
hold on 
surf(a1,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a1,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a1*0+(1-1)*(D+d),b4,z3);
hold on 
surf(a1*0+(1-1)*(D+d)+D,b4,z3);

%% 1_1-21
T21=T21/T;
z1=zeros(1+D*10,1+D*10)+T21;
for i=1:1:1+D*10
    z2(i,:)=z1(i,:)-(i-1)*T21/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T21/(D*10);
end
surf(a1,b2,z1);
hold on 
surf(a1,b2*0+(2-1)*(D+d),z2);
hold on 
surf(a1,b2*0+(2-1)*(D+d)+D,z2);
hold on 
surf(a1*0+(1-1)*(D+d),b2,z3);
hold on 
surf(a1*0+(1-1)*(D+d)+D,b2,z3);

%% 1_1-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a1,b5,z1);
hold on 
surf(a1,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a1,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a1*0+(1-1)*(D+d),b5,z3);
hold on 
surf(a1*0+(1-1)*(D+d)+D,b5,z3);

%% 1_1-31
T31=T31/T;
z1=zeros(1+D*10,1+D*10)+T31;
for i=1:1:1+D*10
    z2(i,:)=z1(i,:)-(i-1)*T31/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T31/(D*10);
end
surf(a1,b3,z1);
hold on 
surf(a1,b3*0+(3-1)*(D+d),z2);
hold on 
surf(a1,b3*0+(3-1)*(D+d)+D,z2);
hold on 
surf(a1*0+(1-1)*(D+d),b3,z3);
hold on 
surf(a1*0+(1-1)*(D+d)+D,b3,z3);

%% 1_2
T11=10^(-3.2605);T12=10^(-2.0279);T13=10^(-0.7429);
T21=10^(-2.0435);T22=10^(-2.0422);
T31=10^(-2.03975);T32=10^(-2.17945);
T=T11+T12+T13+T21+T22+T31+T32;
%T=1;
%% 1_2-11
T11=T11/T;
z1=zeros(1+D*10,1+D*10)+T11;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T11/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T11/(D*10);
end
surf(a4,b1,z1);
hold on 
surf(a4,b1*0+(1-1)*(D+d),z2);
hold on 
surf(a4,b1*0+(1-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b1,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b1,z3);

%% 1_2-12
T12=T12/T;
z1=zeros(1+D*10,1+D*10)+T12;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T12/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T12/(D*10);
end
surf(a4,b4,z1);
hold on 
surf(a4,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a4,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b4,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b4,z3);

%% 1_2-13
T13=T13/T;
z1=zeros(1+D*10,1+D*10)+T13;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T13/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T13/(D*10);
end
surf(a4,b7,z1);
hold on 
surf(a4,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a4,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b7,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b7,z3);

%% 1_2-21
T21=T21/T;
z1=zeros(1+D*10,1+D*10)+T21;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T21/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T21/(D*10);
end
surf(a4,b2,z1);
hold on 
surf(a4,b2*0+(2-1)*(D+d),z2);
hold on 
surf(a4,b2*0+(2-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b2,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b2,z3);

%% 1_2-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a4,b5,z1);
hold on 
surf(a4,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a4,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b5,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b5,z3);

%% 1_2-31
T31=T31/T;
z1=zeros(1+D*10,1+D*10)+T31;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T31/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T31/(D*10);
end
surf(a4,b3,z1);
hold on 
surf(a4,b3*0+(3-1)*(D+d),z2);
hold on 
surf(a4,b3*0+(3-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b3,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b3,z3);

%% 1_2-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a4,b6,z1);
hold on 
surf(a4,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a4,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b6,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b6,z3);

%% 1_3
T13=10^(-2.6104);T14=10^(-0.7055);
T22=10^(-2.0568);T23=10^(-2.2399);
T32=10^(-1.885);T33=10^(-2.66225);
T=T13+T14+T22+T23+T32+T33;
%T=1;
%% 1_3-13
T13=T13/T;
z1=zeros(1+D*10,1+D*10)+T13;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T13/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T13/(D*10);
end
surf(a7,b7,z1);
hold on 
surf(a7,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a7,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b7,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b7,z3);

%% 1_3-14
T14=T14/T;
z1=zeros(1+D*10,1+D*10)+T14;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T14/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T14/(D*10);
end
surf(a7,b10,z1);
hold on 
surf(a7,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a7,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b10,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b10,z3);

%% 1_3-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a7,b5,z1);
hold on 
surf(a7,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a7,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b5,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b5,z3);

%% 1_3-23
T23=T23/T;
z1=zeros(1+D*10,1+D*10)+T23;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T23/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T23/(D*10);
end
surf(a7,b8,z1);
hold on 
surf(a7,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a7,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b8,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b8,z3);

%% 1_3-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a7,b6,z1);
hold on 
surf(a7,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a7,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b6,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b6,z3);

%% 1_3-33
T33=T33/T;
z1=zeros(1+D*10,1+D*10)+T33;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T33/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T33/(D*10);
end
surf(a7,b9,z1);
hold on 
surf(a7,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a7,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b9,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b9,z3);

%% 1_4
z4=zeros(12*(D*10+1),10*D+1+2)+0.001;
aa3=(10-1)*(D+d)-0.1:0.1:(10-1)*(D+d)+D+0.1;
surf(aa3,b,z4);

%% 2
%% 2_1
T11=10^(-2.4891);T12=10^(-1.80055);
T21=10^(-0.632);
T31=10^(-2.13615);T32=10^(-3.02505);
T=T11+T12+T21+T31+T32;
%T=1;
%% 2_1-11
T11=T11/T;
z1=zeros(1+D*10,1+D*10)+T11;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T11/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T11/(D*10);
end
surf(a2,b1,z1);
hold on 
surf(a2,b1*0+(1-1)*(D+d),z2);
hold on 
surf(a2,b1*0+(1-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b1,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b1,z3);

%% 2_1-12
T12=T12/T;
z1=zeros(1+D*10,1+D*10)+T12;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T12/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T12/(D*10);
end
surf(a2,b4,z1);
hold on 
surf(a2,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a2,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b4,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b4,z3);

%% 2_1-21
T21=T21/T;
z1=zeros(1+D*10,1+D*10)+T21;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T21/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T21/(D*10);
end
surf(a2,b2,z1);
hold on 
surf(a2,b2*0+(2-1)*(D+d),z2);
hold on 
surf(a2,b2*0+(2-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b2,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b2,z3);

%% 2_1-31
T31=T31/T;
z1=zeros(1+D*10,1+D*10)+T31;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T31/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T31/(D*10);
end
surf(a2,b3,z1);
hold on 
surf(a2,b3*0+(3-1)*(D+d),z2);
hold on 
surf(a2,b3*0+(3-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b3,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b3,z3);

%% 2_1-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a2,b6,z1);
hold on 
surf(a2,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a2,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b6,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b6,z3);

%% 2_2
T12=10^(-1.889);T13=10^(-3.5525);
T21=10^(-1.77655);T22=10^(-0.5645);
T31=10^(-2.1312);T32=10^(-2.8392);
T=T12+T13+T21+T22+T31+T32;
%T=1;
%% 2_2-12
T12=T12/T;
z1=zeros(1+D*10,1+D*10)+T12;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T12/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T12/(D*10);
end
surf(a5,b4,z1);
hold on 
surf(a5,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a5,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b4,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b4,z3);

%% 2_2-13
T13=T13/T;
z1=zeros(1+D*10,1+D*10)+T13;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T13/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T13/(D*10);
end
surf(a5,b7,z1);
hold on 
surf(a5,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a5,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b7,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b7,z3);

%% 2_2-21
T21=T21/T;
z1=zeros(1+D*10,1+D*10)+T21;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T21/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T21/(D*10);
end
surf(a5,b2,z1);
hold on 
surf(a5,b2*0+(2-1)*(D+d),z2);
hold on 
surf(a5,b2*0+(2-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b2,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b2,z3);

%% 2_2-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a5,b5,z1);
hold on 
surf(a5,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a5,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b5,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b5,z3);

%% 2_2-31
T31=T31/T;
z1=zeros(1+D*10,1+D*10)+T31;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T31/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T31/(D*10);
end
surf(a5,b3,z1);
hold on 
surf(a5,b3*0+(3-1)*(D+d),z2);
hold on 
surf(a5,b3*0+(3-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b3,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b3,z3);

%% 2_2-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a5,b6,z1);
hold on 
surf(a5,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a5,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b6,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b6,z3);

%% 2_3
T12=10^(-3.38825);T13=10^(-2.96265);T14=10^(-2.0003);
T22=10^(-1.7488);T23=10^(-0.52);
T32=10^(-1.74345);T33=10^(-2.67735);
T=T12+T13+T14+T22+T23+T32+T33;
%T=1;
%% 2_3-12
T12=T12/T;
z1=zeros(1+D*10,1+D*10)+T12;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T12/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T12/(D*10);
end
surf(a8,b4,z1);
hold on 
surf(a8,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a8,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b4,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b4,z3);

%% 2_3-13
T13=T13/T;
z1=zeros(1+D*10,1+D*10)+T13;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T13/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T13/(D*10);
end
surf(a8,b7,z1);
hold on 
surf(a8,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a8,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b7,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b7,z3);

%% 2_3-14
T14=T14/T;
z1=zeros(1+D*10,1+D*10)+T14;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T14/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T14/(D*10);
end
surf(a8,b10,z1);
hold on 
surf(a8,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a8,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b10,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b10,z3);

%% 2_3-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a8,b5,z1);
hold on 
surf(a8,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a8,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b5,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b5,z3);

%% 2_3-23
T23=T23/T;
z1=zeros(1+D*10,1+D*10)+T23;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T23/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T23/(D*10);
end
surf(a8,b8,z1);
hold on 
surf(a8,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a8,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b8,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b8,z3);

%% 2_3-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a8,b6,z1);
hold on 
surf(a8,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a8,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b6,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b6,z3);

%% 2_3-33
T33=T33/T;
z1=zeros(1+D*10,1+D*10)+T33;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T33/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T33/(D*10);
end
surf(a8,b9,z1);
hold on 
surf(a8,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a8,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b9,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b9,z3);

%% 2_4
T14=10^(-1.68555);
T23=10^(-1.81035);T24=10^(-0.5695);
T33=10^(-1.8441);T34=10^(-1.8746);
T=T14+T23+T24+T33+T34;
%T=1;
%% 2_4-14
T14=T14/T;
z1=zeros(1+D*10,1+D*10)+T14;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T14/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T14/(D*10);
end
surf(a11,b10,z1);
hold on 
surf(a11,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a11,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a11*0+(11-1)*(D+d),b10,z3);
hold on 
surf(a11*0+(11-1)*(D+d)+D,b10,z3);

%% 2_4-23
T23=T23/T;
z1=zeros(1+D*10,1+D*10)+T23;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T23/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T23/(D*10);
end
surf(a11,b8,z1);
hold on 
surf(a11,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a11,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a11*0+(11-1)*(D+d),b8,z3);
hold on 
surf(a11*0+(11-1)*(D+d)+D,b8,z3);

%% 2_4-24
T24=T24/T;
z1=zeros(1+D*10,1+D*10)+T24;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T24/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T24/(D*10);
end
surf(a11,b11,z1);
hold on 
surf(a11,b11*0+(11-1)*(D+d),z2);
hold on 
surf(a11,b11*0+(11-1)*(D+d)+D,z2);
hold on 
surf(a11*0+(11-1)*(D+d),b11,z3);
hold on 
surf(a11*0+(11-1)*(D+d)+D,b11,z3);

%% 2_4-33
T33=T33/T;
z1=zeros(1+D*10,1+D*10)+T33;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T33/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T33/(D*10);
end
surf(a11,b9,z1);
hold on 
surf(a11,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a11,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a11*0+(11-1)*(D+d),b9,z3);
hold on 
surf(a11*0+(11-1)*(D+d)+D,b9,z3);

%% 2_4-34
T34=T34/T;
z1=zeros(1+D*10,1+D*10)+T34;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T34/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T34/(D*10);
end
surf(a11,b12,z1);
hold on 
surf(a11,b12*0+(12-1)*(D+d),z2);
hold on 
surf(a11,b12*0+(12-1)*(D+d)+D,z2);
hold on 
surf(a11*0+(11-1)*(D+d),b12,z3);
hold on 
surf(a11*0+(11-1)*(D+d)+D,b12,z3);

%% 3
%% 3_1
z4=zeros(12*(D*10+1),10*D+1+2)+0.001;
aa3=(3-1)*(D+d)-0.1:0.1:(3-1)*(D+d)+D+0.1;
surf(aa3,b,z4);

%% 3_2
T12=10^(-1.80155);T13=10^(-1.7747);
T21=10^(-1.88235);T22=10^(-2.57665);
T31=10^(-0.50225);T32=10^(-3.436);
T=T12+T13+T21+T22+T31+T32;
%T=1;
%% 3_2-12
T12=T12/T;
z1=zeros(1+D*10,1+D*10)+T12;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T12/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T12/(D*10);
end
surf(a6,b4,z1);
hold on 
surf(a6,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a6,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b4,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b4,z3);

%% 3_2-13
T13=T13/T;
z1=zeros(1+D*10,1+D*10)+T13;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T13/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T13/(D*10);
end
surf(a6,b7,z1);
hold on 
surf(a6,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a6,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b7,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b7,z3);

%% 3_2-21
T21=T21/T;
z1=zeros(1+D*10,1+D*10)+T21;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T21/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T21/(D*10);
end
surf(a6,b2,z1);
hold on 
surf(a6,b2*0+(2-1)*(D+d),z2);
hold on 
surf(a6,b2*0+(2-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b2,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b2,z3);

%% 3_2-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a6,b5,z1);
hold on 
surf(a6,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a6,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b5,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b5,z3);

%% 3_2-31
T31=T31/T;
z1=zeros(1+D*10,1+D*10)+T31;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T31/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T31/(D*10);
end
surf(a6,b3,z1);
hold on 
surf(a6,b3*0+(3-1)*(D+d),z2);
hold on 
surf(a6,b3*0+(3-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b3,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b3,z3);

%% 3_2-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a6,b6,z1);
hold on 
surf(a6,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a6,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b6,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b6,z3);

%% 3_3
T13=10^(-1.7273);T14=10^(-1.92385);
T22=10^(-1.98585);T23=10^(-2.0042);
T32=10^(-0.5149);T33=10^(-2.0024);
T=T13+T14+T22+T23+T32+T33;
%T=1;
%% 3_3-13
T13=T13/T;
z1=zeros(1+D*10,1+D*10)+T13;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T13/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T13/(D*10);
end
surf(a9,b7,z1);
hold on 
surf(a9,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a9,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b7,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b7,z3);

%% 3_3-14
T14=T14/T;
z1=zeros(1+D*10,1+D*10)+T14;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T14/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T14/(D*10);
end
surf(a9,b10,z1);
hold on 
surf(a9,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a9,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b10,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b10,z3);

%% 3_3-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a9,b5,z1);
hold on 
surf(a9,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a9,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b5,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b5,z3);

%% 3_3-23
T23=T23/T;
z1=zeros(1+D*10,1+D*10)+T23;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T23/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T23/(D*10);
end
surf(a9,b8,z1);
hold on 
surf(a9,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a9,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b8,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b8,z3);

%% 3_3-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a9,b6,z1);
hold on 
surf(a9,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a9,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b6,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b6,z3);

%% 3_3-33
T33=T33/T;
z1=zeros(1+D*10,1+D*10)+T33;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T33/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T33/(D*10);
end
surf(a9,b9,z1);
hold on 
surf(a9,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a9,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b9,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b9,z3);

%% 3_4
T14=10^(-1.75715);
T23=10^(-2.58715);T24=10^(-1.898);
T33=10^(-0.4419);T34=10^(-2.0766);
T=T14+T23+T24+T33+T34;
%T=1;
%% 3_4-14
T14=T14/T;
z1=zeros(1+D*10,1+D*10)+T14;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T14/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T14/(D*10);
end
surf(a12,b10,z1);
hold on 
surf(a12,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a12,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a12*0+(12-1)*(D+d),b10,z3);
hold on 
surf(a12*0+(12-1)*(D+d)+D,b10,z3);

%% 3_4-23
T23=T23/T;
z1=zeros(1+D*10,1+D*10)+T23;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T23/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T23/(D*10);
end
surf(a12,b8,z1);
hold on 
surf(a12,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a12,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a12*0+(12-1)*(D+d),b8,z3);
hold on 
surf(a12*0+(12-1)*(D+d)+D,b8,z3);

%% 3_4-24
T24=T24/T;
z1=zeros(1+D*10,1+D*10)+T24;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T24/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T24/(D*10);
end
surf(a12,b11,z1);
hold on 
surf(a12,b11*0+(11-1)*(D+d),z2);
hold on 
surf(a12,b11*0+(11-1)*(D+d)+D,z2);
hold on 
surf(a12*0+(12-1)*(D+d),b11,z3);
hold on 
surf(a12*0+(12-1)*(D+d)+D,b11,z3);

%% 3_4-33
T33=T33/T;
z1=zeros(1+D*10,1+D*10)+T33;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T33/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T33/(D*10);
end
surf(a12,b9,z1);
hold on 
surf(a12,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a12,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a12*0+(12-1)*(D+d),b9,z3);
hold on 
surf(a12*0+(12-1)*(D+d)+D,b9,z3);

%% 3_4-34
T34=T34/T;
z1=zeros(1+D*10,1+D*10)+T34;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T34/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T34/(D*10);
end
surf(a12,b12,z1);
hold on 
surf(a12,b12*0+(12-1)*(D+d),z2);
hold on 
surf(a12,b12*0+(12-1)*(D+d)+D,z2);
hold on 
surf(a12*0+(12-1)*(D+d),b12,z3);
hold on 
surf(a12*0+(12-1)*(D+d)+D,b12,z3);

shading flat%网格化

p1=0:0.1:(12-1)*(D+d)+D;
q1=(12-1)*(D+d)+D+0*p1;
z1=1+0*p1;
plot3(p1,q1,z1,'color',[0.75 0.75 0.75],'linewidth',1);

q2=0.1:0.1:(12-1)*(D+d)+D;
p2=(12-1)*(D+d)+D+0*q2;
z2=1+0*q2;
plot3(p2,q2,z2,'color',[0.75 0.75 0.75],'linewidth',1);

z3=0:0.1:1;
p3=0+0*z3;
q3=(12-1)*(D+d)+D+0*z3;
p4=(12-1)*(D+d)+D+0*z3;
q4=(12-1)*(D+d)+D+0*z3;
p5=(12-1)*(D+d)+D+0*z3;
q5=0.1+0*z3;
plot3(p3,q3,z3,'color',[0.75 0.75 0.75],'linewidth',1);
hold on
plot3(p4,q4,z3,'color',[0.75 0.75 0.75],'linewidth',1);
hold on
plot3(p5,q5,z3,'color',[0.75 0.75 0.75],'linewidth',1);

q6=(12-1)*(D+d)+D:0.1:(12-1)*(D+d)+D+0.6*D;
p6=0*q6;
z6=0+0*q6;z7=0.5+0*q6;z8=1+0*q6;
plot3(p6,q6,z6,'color',[0 0 0],'linewidth',1.5);
hold on
plot3(p6,q6,z7,'color',[0 0 0],'linewidth',1.5);
hold on
plot3(p6,q6,z8,'color',[0 0 0],'linewidth',1.5);

for i=1:1:12
    p=-0.6*D:0.1:0;
    q=(i-1)*(D+d)+0.5*D+0*p;
    z=0*p;
    plot3(p,q,z,'color',[0 0 0],'linewidth',1.5);
    hold on
end

for i=1:1:12
    q=-0.6*D:0.1:0;
    p=(i-1)*(D+d)+0.5*D+0*q;
    z=0*q;
    plot3(p,q,z,'color',[0 0 0],'linewidth',1.5);
    hold on
end

colorbar; colormap(hot);
clim([0 1]);
view(-64.8131,76.8)

set(gca,'xcolor',[1 1 1]);
set(gca,'ycolor',[1 1 1]);
set(gca,'zcolor',[1 1 1]);
set(gcf,'color',[1 1 1]);



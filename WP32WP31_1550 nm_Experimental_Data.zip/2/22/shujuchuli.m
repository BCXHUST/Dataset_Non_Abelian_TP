N=501;

%num='13';

ss=['2-1-2-7-22-12-1';'2-1-2-7-22-13-1';'2-1-2-7-22-21-1';'2-1-2-7-22-22-1';'2-1-2-7-22-31-1';'2-1-2-7-22-32-1'];

for nn=1:1:6
fid = fopen([ss(nn,:),'.csv'], 'r');                                          
symble=0;
D1=zeros(1,N);
D2=zeros(1,N);
while ~feof(fid)
    tline=fgetl(fid);
    if ~isempty(tline)
        if symble==0
            if tline(2)=='['
                symble=symble+1;
            end
        elseif symble>0
            data=textscan(tline,'%f,%f');
            data=cell2mat(data);
            D1(symble)=data(1); %波长
            D2(symble)=data(2); %数据
            symble=symble+1;
            clear data
        end
    end
end
fclose(fid);

sss=['12';'13';'21';'22';'31';'32'];
eval(['a',sss(nn,:),'=D2;']);
end
l=D1; 
figure(1);
hold on
plot(l,a12-s2222-s1212);
plot(l,a13-s2222-s1313);
plot(l,a21-s2222-s2121);
plot(l,a22-s2222-s2222,'color',[0,0,0]);
plot(l,a31-s2222-s3131);
plot(l,a32-s2222-s3232);
%legend('21','31','12','22','32','13');
axis([1549,1551,-50,0]);
%axis([1550,1560,-50,10]);
% plot(lambda,10*log10(TTT43));
% hold on;
% plot(lambda,10*log10(TTT44));
% hold on;
% plot(lambda,10*log10(TTT44),'--');
% hold on;
% plot(lambda,10*log10(TTT34));
% axis([1400,1700,-50,0]);

%title('TE输入');
%figure(2);
%hold on
%plot(l,a23-s1-s2);
%plot(l,a24-s2-s2);
%plot(l,a42-s1-s2);
%plot(l,a41-s2-s2);
%title('TM输入');
% axis([1530,1570,-50,0]);
% plot(lambda,10*log10(TTT43));
% hold on;
% plot(lambda,10*log10(TTT33));
% hold on;
% plot(lambda,10*log10(TTT33),'--');
% hold on;
% plot(lambda,10*log10(TTT34));
% hold on;





D=1.7;d=0.8;%D为柱子宽度，d为柱子间距

for i=1:1:12
    a1=0:0.1:D;%每个柱子的宽度
    aa = ['a',num2str(i),'=a1+(D+d)*(i-1);'];
    eval(aa);
    b1=0:0.1:D;%每个柱子的宽度
    bb = ['b',num2str(i),'=b1+(D+d)*(i-1);'];
    eval(bb);
end
a=[a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12];
b=[b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12];
z1=zeros(1+D*10,1+D*10)+0.001;%零矩阵行列为柱子宽度+1
z2=zeros(1+D*10,1+D*10)+0.001;
z3=zeros(1+D*10,1+D*10)+0.001;
figure(1)
for i=1:1:12
    cc=['a',num2str(i)];
    c=eval(cc);
    for j=1:1:12
        ee=['b',num2str(j)];
        e=eval(ee);
        surf(c,e,z1);
        hold on
    end
end

%% 1
%% 1_1
z4=zeros(12*(D*10+1),10*D+1+1)+0.001;
aa3=(1-1)*(D+d):0.1:(1-1)*(D+d)+D+0.1;
surf(aa3,b,z4);

%% 1_2
T11=10^(-0.66205);T12=10^(-2.2112);
T21=10^(-1.7334);T22=10^(-1.9234);
T31=10^(-1.9015);
T=T11+T12+T21+T22+T31;
%T=1;
%% 1_2-11
T11=T11/T;
z1=zeros(1+D*10,1+D*10)+T11;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T11/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T11/(D*10);
end
surf(a4,b1,z1);
hold on 
surf(a4,b1*0+(1-1)*(D+d),z2);
hold on 
surf(a4,b1*0+(1-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b1,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b1,z3);

%% 1_2-12
T12=T12/T;
z1=zeros(1+D*10,1+D*10)+T12;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T12/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T12/(D*10);
end
surf(a4,b4,z1);
hold on 
surf(a4,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a4,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b4,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b4,z3);

%% 1_2-21
T21=T21/T;
z1=zeros(1+D*10,1+D*10)+T21;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T21/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T21/(D*10);
end
surf(a4,b2,z1);
hold on 
surf(a4,b2*0+(2-1)*(D+d),z2);
hold on 
surf(a4,b2*0+(2-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b2,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b2,z3);

%% 1_2-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a4,b5,z1);
hold on 
surf(a4,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a4,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b5,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b5,z3);

%% 1_2-31
T31=T31/T;
z1=zeros(1+D*10,1+D*10)+T31;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T31/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T31/(D*10);
end
surf(a4,b3,z1);
hold on 
surf(a4,b3*0+(3-1)*(D+d),z2);
hold on 
surf(a4,b3*0+(3-1)*(D+d)+D,z2);
hold on 
surf(a4*0+(4-1)*(D+d),b3,z3);
hold on 
surf(a4*0+(4-1)*(D+d)+D,b3,z3);

%% 1_3
T11=10^(-3.01035);T12=10^(-0.57235);T13=10^(-1.7307);
T21=10^(-3.18785);T22=10^(-1.9647);T23=10^(-1.9477);
T31=10^(-3.4157);T32=10^(-3.3138);T33=10^(-2.21625);
T=T11+T12+T13+T21+T22+T23+T31+T32+T33;
%T=1;
%% 1_3-11
T11=T11/T;
z1=zeros(1+D*10,1+D*10)+T11;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T11/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T11/(D*10);
end
surf(a7,b1,z1);
hold on 
surf(a7,b1*0+(1-1)*(D+d),z2);
hold on 
surf(a7,b1*0+(1-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b1,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b1,z3);

%% 1_3-12
T12=T12/T;
z1=zeros(1+D*10,1+D*10)+T12;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T12/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T12/(D*10);
end
surf(a7,b4,z1);
hold on 
surf(a7,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a7,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b4,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b4,z3);

%% 1_3-13
T13=T13/T;
z1=zeros(1+D*10,1+D*10)+T13;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T13/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T13/(D*10);
end
surf(a7,b7,z1);
hold on 
surf(a7,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a7,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b7,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b7,z3);

%% 1_3-21
T21=T21/T;
z1=zeros(1+D*10,1+D*10)+T21;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T21/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T21/(D*10);
end
surf(a7,b2,z1);
hold on 
surf(a7,b2*0+(2-1)*(D+d),z2);
hold on 
surf(a7,b2*0+(2-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b2,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b2,z3);

%% 1_3-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a7,b5,z1);
hold on 
surf(a7,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a7,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b5,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b5,z3);

%% 1_3-23
T23=T23/T;
z1=zeros(1+D*10,1+D*10)+T23;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T23/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T23/(D*10);
end
surf(a7,b8,z1);
hold on 
surf(a7,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a7,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b8,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b8,z3);

%% 1_3-31
T31=T31/T;
z1=zeros(1+D*10,1+D*10)+T31;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T31/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T31/(D*10);
end
surf(a7,b3,z1);
hold on 
surf(a7,b3*0+(3-1)*(D+d),z2);
hold on 
surf(a7,b3*0+(3-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b3,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b3,z3);

%% 1_3-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a7,b6,z1);
hold on 
surf(a7,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a7,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b6,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b6,z3);

%% 1_3-33
T33=T33/T;
z1=zeros(1+D*10,1+D*10)+T33;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T33/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T33/(D*10);
end
surf(a7,b9,z1);
hold on 
surf(a7,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a7,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a7*0+(7-1)*(D+d),b9,z3);
hold on 
surf(a7*0+(7-1)*(D+d)+D,b9,z3);

%% 1_4
T13=10^(-0.72095);T14=10^(-3.0407);
T23=10^(-2.0886);T24=10^(-1.89965);
T32=10^(-2.40075);T33=10^(-2.2475);T34=10^(-2.53815);
T=T13+T14+T23+T24+T32+T33+T34;
%T=1;
%% 1_4-13
T13=T13/T;
z1=zeros(1+D*10,1+D*10)+T13;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T13/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T13/(D*10);
end
surf(a10,b7,z1);
hold on 
surf(a10,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a10,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a10*0+(10-1)*(D+d),b7,z3);
hold on 
surf(a10*0+(10-1)*(D+d)+D,b7,z3);

%% 1_4-14
T14=T14/T;
z1=zeros(1+D*10,1+D*10)+T14;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T14/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T14/(D*10);
end
surf(a10,b10,z1);
hold on 
surf(a10,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a10,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a10*0+(10-1)*(D+d),b10,z3);
hold on 
surf(a10*0+(10-1)*(D+d)+D,b10,z3);

%% 1_4-23
T23=T23/T;
z1=zeros(1+D*10,1+D*10)+T23;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T23/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T23/(D*10);
end
surf(a10,b8,z1);
hold on 
surf(a10,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a10,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a10*0+(10-1)*(D+d),b8,z3);
hold on 
surf(a10*0+(10-1)*(D+d)+D,b8,z3);

%% 1_4-24
T24=T24/T;
z1=zeros(1+D*10,1+D*10)+T24;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T24/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T24/(D*10);
end
surf(a10,b11,z1);
hold on 
surf(a10,b11*0+(11-1)*(D+d),z2);
hold on 
surf(a10,b11*0+(11-1)*(D+d)+D,z2);
hold on 
surf(a10*0+(10-1)*(D+d),b11,z3);
hold on 
surf(a10*0+(10-1)*(D+d)+D,b11,z3);

%% 1_4-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a10,b6,z1);
hold on 
surf(a10,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a10,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a10*0+(10-1)*(D+d),b6,z3);
hold on 
surf(a10*0+(10-1)*(D+d)+D,b6,z3);

%% 1_4-33
T33=T33/T;
z1=zeros(1+D*10,1+D*10)+T33;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T33/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T33/(D*10);
end
surf(a10,b9,z1);
hold on 
surf(a10,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a10,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a10*0+(10-1)*(D+d),b9,z3);
hold on 
surf(a10*0+(10-1)*(D+d)+D,b9,z3);

%% 1_4-34
T34=T34/T;
z1=zeros(1+D*10,1+D*10)+T34;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T34/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T34/(D*10);
end
surf(a10,b12,z1);
hold on 
surf(a10,b12*0+(12-1)*(D+d),z2);
hold on 
surf(a10,b12*0+(12-1)*(D+d)+D,z2);
hold on 
surf(a10*0+(10-1)*(D+d),b12,z3);
hold on 
surf(a10*0+(10-1)*(D+d)+D,b12,z3);

%% 2
%% 2_1
T11=10^(-2.17925);T12=10^(-2.10035);
T21=10^(-2.35);T22=10^(-1.00595);
T31=10^(-2.33865);T32=10^(-2.64405);
T=T11+T12+T21+T22+T31+T32;
%T=1;
%% 2_1-11
T11=T11/T;
z1=zeros(1+D*10,1+D*10)+T11;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T11/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T11/(D*10);
end
surf(a2,b1,z1);
hold on 
surf(a2,b1*0+(1-1)*(D+d),z2);
hold on 
surf(a2,b1*0+(1-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b1,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b1,z3);

%% 2_1-12
T12=T12/T;
z1=zeros(1+D*10,1+D*10)+T12;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T12/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T12/(D*10);
end
surf(a2,b4,z1);
hold on 
surf(a2,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a2,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b4,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b4,z3);

%% 2_1-21
T21=T21/T;
z1=zeros(1+D*10,1+D*10)+T21;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T21/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T21/(D*10);
end
surf(a2,b2,z1);
hold on 
surf(a2,b2*0+(2-1)*(D+d),z2);
hold on 
surf(a2,b2*0+(2-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b2,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b2,z3);

%% 2_1-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a2,b5,z1);
hold on 
surf(a2,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a2,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b5,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b5,z3);


%% 2_1-31
T31=T31/T;
z1=zeros(1+D*10,1+D*10)+T31;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T31/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T31/(D*10);
end
surf(a2,b3,z1);
hold on 
surf(a2,b3*0+(3-1)*(D+d),z2);
hold on 
surf(a2,b3*0+(3-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b3,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b3,z3);

%% 2_1-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a2,b6,z1);
hold on 
surf(a2,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a2,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a2*0+(2-1)*(D+d),b6,z3);
hold on 
surf(a2*0+(2-1)*(D+d)+D,b6,z3);

%% 2_2
T12=10^(-2.0868);T13=10^(-2.0017);
T22=10^(-2.0824);T23=10^(-0.88375);
T32=10^(-3.2664);T33=10^(-1.98895);
T=T12+T13+T22+T23+T32+T33;
%T=1;
%% 2_2-12
T12=T12/T;
z1=zeros(1+D*10,1+D*10)+T12;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T12/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T12/(D*10);
end
surf(a5,b4,z1);
hold on 
surf(a5,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a5,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b4,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b4,z3);

%% 2_2-13
T13=T13/T;
z1=zeros(1+D*10,1+D*10)+T13;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T13/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T13/(D*10);
end
surf(a5,b7,z1);
hold on 
surf(a5,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a5,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b7,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b7,z3);

%% 2_2-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a5,b5,z1);
hold on 
surf(a5,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a5,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b5,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b5,z3);

%% 2_2-23
T23=T23/T;
z1=zeros(1+D*10,1+D*10)+T23;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T23/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T23/(D*10);
end
surf(a5,b8,z1);
hold on 
surf(a5,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a5,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b8,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b8,z3);

%% 2_2-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a5,b6,z1);
hold on 
surf(a5,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a5,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b6,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b6,z3);

%% 2_2-33
T33=T33/T;
z1=zeros(1+D*10,1+D*10)+T33;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T33/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T33/(D*10);
end
surf(a5,b9,z1);
hold on 
surf(a5,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a5,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a5*0+(5-1)*(D+d),b9,z3);
hold on 
surf(a5*0+(5-1)*(D+d)+D,b9,z3);

%% 2_3
T13=10^(-2.05595);T14=10^(-2.9294);
T23=10^(-1.9813);T24=10^(-0.88295);
T32=10^(-2.62435);T33=10^(-2.123);T34=10^(-2.01515);
T=T13+T14+T23+T24+T32+T33+T34;
%T=1;
%% 2_3-13
T13=T13/T;
z1=zeros(1+D*10,1+D*10)+T13;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T13/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T13/(D*10);
end
surf(a8,b7,z1);
hold on 
surf(a8,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a8,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b7,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b7,z3);

%% 2_3-14
T14=T14/T;
z1=zeros(1+D*10,1+D*10)+T14;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T14/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T14/(D*10);
end
surf(a8,b10,z1);
hold on 
surf(a8,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a8,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b10,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b10,z3);

%% 2_3-23
T23=T23/T;
z1=zeros(1+D*10,1+D*10)+T23;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T23/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T23/(D*10);
end
surf(a8,b8,z1);
hold on 
surf(a8,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a8,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b8,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b8,z3);

%% 2_3-24
T24=T24/T;
z1=zeros(1+D*10,1+D*10)+T24;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T24/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T24/(D*10);
end
surf(a8,b11,z1);
hold on 
surf(a8,b11*0+(11-1)*(D+d),z2);
hold on 
surf(a8,b11*0+(11-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b11,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b11,z3);

%% 2_3-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a8,b6,z1);
hold on 
surf(a8,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a8,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b6,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b6,z3);

%% 2_3-33
T33=T33/T;
z1=zeros(1+D*10,1+D*10)+T33;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T33/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T33/(D*10);
end
surf(a8,b9,z1);
hold on 
surf(a8,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a8,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b9,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b9,z3);

%% 2_3-34
T34=T34/T;
z1=zeros(1+D*10,1+D*10)+T34;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T34/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T34/(D*10);
end
surf(a8,b12,z1);
hold on 
surf(a8,b12*0+(12-1)*(D+d),z2);
hold on 
surf(a8,b12*0+(12-1)*(D+d)+D,z2);
hold on 
surf(a8*0+(8-1)*(D+d),b12,z3);
hold on 
surf(a8*0+(8-1)*(D+d)+D,b12,z3);

%% 2_4
z4=zeros(12*(D*10+1),10*D+1+2)+0.001;
aa3=(11-1)*(D+d)-0.1:0.1:(11-1)*(D+d)+D+0.1;
surf(aa3,b,z4);

%% 3
%% 3_1
T11=10^(-2.01795);T12=10^(-1.8629);
T21=10^(-1.862);T22=10^(-1.994);
T31=10^(-0.6955);T32=10^(-2.11485);
T=T11+T12+T21+T22+T31+T32;
%T=1;
%% 3_1-11
T11=T11/T;
z1=zeros(1+D*10,1+D*10)+T11;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T11/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T11/(D*10);
end
surf(a3,b1,z1);
hold on 
surf(a3,b1*0+(1-1)*(D+d),z2);
hold on 
surf(a3,b1*0+(1-1)*(D+d)+D,z2);
hold on 
surf(a3*0+(3-1)*(D+d),b1,z3);
hold on 
surf(a3*0+(3-1)*(D+d)+D,b1,z3);

%% 3_1-12
T12=T12/T;
z1=zeros(1+D*10,1+D*10)+T12;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T12/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T12/(D*10);
end
surf(a3,b4,z1);
hold on 
surf(a3,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a3,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a3*0+(3-1)*(D+d),b4,z3);
hold on 
surf(a3*0+(3-1)*(D+d)+D,b4,z3);

%% 3_1-21
T21=T21/T;
z1=zeros(1+D*10,1+D*10)+T21;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T21/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T21/(D*10);
end
surf(a3,b2,z1);
hold on 
surf(a3,b2*0+(2-1)*(D+d),z2);
hold on 
surf(a3,b2*0+(2-1)*(D+d)+D,z2);
hold on 
surf(a3*0+(3-1)*(D+d),b2,z3);
hold on 
surf(a3*0+(3-1)*(D+d)+D,b2,z3);

%% 3_1-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a3,b5,z1);
hold on 
surf(a3,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a3,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a3*0+(3-1)*(D+d),b5,z3);
hold on 
surf(a3*0+(3-1)*(D+d)+D,b5,z3);

%% 3_1-31
T31=T31/T;
z1=zeros(1+D*10,1+D*10)+T31;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T31/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T31/(D*10);
end
surf(a3,b3,z1);
hold on 
surf(a3,b3*0+(3-1)*(D+d),z2);
hold on 
surf(a3,b3*0+(3-1)*(D+d)+D,z2);
hold on 
surf(a3*0+(3-1)*(D+d),b3,z3);
hold on 
surf(a3*0+(3-1)*(D+d)+D,b3,z3);

%% 3_1-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a3,b6,z1);
hold on 
surf(a3,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a3,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a3*0+(3-1)*(D+d),b6,z3);
hold on 
surf(a3*0+(3-1)*(D+d)+D,b6,z3);

%% 3_2
T11=10^(-2.8738);T12=10^(-1.81245);T13=10^(-1.92095);
T21=10^(-2.90535);T22=10^(-1.98615);T23=10^(-2.00545);
T31=10^(-2.77595);T32=10^(-0.5398);T33=10^(-1.9119);
T=T11+T12+T13+T21+T22+T23+T31+T32+T33;
%T=1;
%% 3_2-11
T11=T11/T;
z1=zeros(1+D*10,1+D*10)+T11;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T11/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T11/(D*10);
end
surf(a6,b1,z1);
hold on 
surf(a6,b1*0+(1-1)*(D+d),z2);
hold on 
surf(a6,b1*0+(1-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b1,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b1,z3);

%% 3_2-12
T12=T12/T;
z1=zeros(1+D*10,1+D*10)+T12;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T12/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T12/(D*10);
end
surf(a6,b4,z1);
hold on 
surf(a6,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a6,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b4,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b4,z3);

%% 3_2-13
T13=T13/T;
z1=zeros(1+D*10,1+D*10)+T13;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T13/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T13/(D*10);
end
surf(a6,b7,z1);
hold on 
surf(a6,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a6,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b7,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b7,z3);

%% 3_2-21
T21=T21/T;
z1=zeros(1+D*10,1+D*10)+T21;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T21/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T21/(D*10);
end
surf(a6,b2,z1);
hold on 
surf(a6,b2*0+(2-1)*(D+d),z2);
hold on 
surf(a6,b2*0+(2-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b2,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b2,z3);

%% 3_2-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a6,b5,z1);
hold on 
surf(a6,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a6,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b5,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b5,z3);

%% 3_2-23
T23=T23/T;
z1=zeros(1+D*10,1+D*10)+T23;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T23/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T23/(D*10);
end
surf(a6,b8,z1);
hold on 
surf(a6,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a6,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b8,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b8,z3);

%% 3_2-31
T31=T31/T;
z1=zeros(1+D*10,1+D*10)+T31;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T31/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T31/(D*10);
end
surf(a6,b3,z1);
hold on 
surf(a6,b3*0+(3-1)*(D+d),z2);
hold on 
surf(a6,b3*0+(3-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b3,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b3,z3);

%% 3_2-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a6,b6,z1);
hold on 
surf(a6,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a6,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b6,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b6,z3);

%% 3_2-33
T33=T33/T;
z1=zeros(1+D*10,1+D*10)+T33;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T33/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T33/(D*10);
end
surf(a6,b9,z1);
hold on 
surf(a6,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a6,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a6*0+(6-1)*(D+d),b9,z3);
hold on 
surf(a6*0+(6-1)*(D+d)+D,b9,z3);

%% 3_3
T12=10^(-3.13305);T13=10^(-1.79275);T14=10^(-2.59805);
T22=10^(-2.76975);T23=10^(-1.8317);T24=10^(-1.8966);
T32=10^(-3.06915);T33=10^(-0.6357);T34=10^(-2.7317);
T=T12+T13+T14+T22+T23+T24+T32+T33+T34;
%T=1;
%% 3_3-12
T12=T12/T;
z1=zeros(1+D*10,1+D*10)+T12;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T12/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T12/(D*10);
end
surf(a9,b4,z1);
hold on 
surf(a9,b4*0+(4-1)*(D+d),z2);
hold on 
surf(a9,b4*0+(4-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b4,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b4,z3);

%% 3_3-13
T13=T13/T;
z1=zeros(1+D*10,1+D*10)+T13;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T13/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T13/(D*10);
end
surf(a9,b7,z1);
hold on 
surf(a9,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a9,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b7,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b7,z3);

%% 3_3-14
T14=T14/T;
z1=zeros(1+D*10,1+D*10)+T14;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T14/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T14/(D*10);
end
surf(a9,b10,z1);
hold on 
surf(a9,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a9,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b10,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b10,z3);

%% 3_3-22
T22=T22/T;
z1=zeros(1+D*10,1+D*10)+T22;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T22/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T22/(D*10);
end
surf(a9,b5,z1);
hold on 
surf(a9,b5*0+(5-1)*(D+d),z2);
hold on 
surf(a9,b5*0+(5-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b5,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b5,z3);

%% 3_3-23
T23=T23/T;
z1=zeros(1+D*10,1+D*10)+T23;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T23/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T23/(D*10);
end
surf(a9,b8,z1);
hold on 
surf(a9,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a9,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b8,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b8,z3);

%% 3_3-24
T24=T24/T;
z1=zeros(1+D*10,1+D*10)+T24;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T24/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T24/(D*10);
end
surf(a9,b11,z1);
hold on 
surf(a9,b11*0+(11-1)*(D+d),z2);
hold on 
surf(a9,b11*0+(11-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b11,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b11,z3);

%% 3_3-32
T32=T32/T;
z1=zeros(1+D*10,1+D*10)+T32;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T32/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T32/(D*10);
end
surf(a9,b6,z1);
hold on 
surf(a9,b6*0+(6-1)*(D+d),z2);
hold on 
surf(a9,b6*0+(6-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b6,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b6,z3);

%% 3_3-33
T33=T33/T;
z1=zeros(1+D*10,1+D*10)+T33;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T33/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T33/(D*10);
end
surf(a9,b9,z1);
hold on 
surf(a9,b9*0+(9-1)*(D+d),z2);
hold on 
surf(a9,b9*0+(9-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b9,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b9,z3);

%% 3_3-34
T34=T34/T;
z1=zeros(1+D*10,1+D*10)+T34;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T34/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T34/(D*10);
end
surf(a9,b12,z1);
hold on 
surf(a9,b12*0+(12-1)*(D+d),z2);
hold on 
surf(a9,b12*0+(12-1)*(D+d)+D,z2);
hold on 
surf(a9*0+(9-1)*(D+d),b12,z3);
hold on 
surf(a9*0+(9-1)*(D+d)+D,b12,z3);

%% 3_4
T13=10^(-3.33955);T14=10^(-1.83125);
T23=10^(-2.90075);T24=10^(-1.9779);
T34=10^(-0.6026);
T=T13+T14+T23+T24+T34;
%T=1;
%% 3_4-13
T13=T13/T;
z1=zeros(1+D*10,1+D*10)+T13;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T13/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T13/(D*10);
end
surf(a12,b7,z1);
hold on 
surf(a12,b7*0+(7-1)*(D+d),z2);
hold on 
surf(a12,b7*0+(7-1)*(D+d)+D,z2);
hold on 
surf(a12*0+(12-1)*(D+d),b7,z3);
hold on 
surf(a12*0+(12-1)*(D+d)+D,b7,z3);

%% 3_4-14
T14=T14/T;
z1=zeros(1+D*10,1+D*10)+T14;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T14/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T14/(D*10);
end
surf(a12,b10,z1);
hold on 
surf(a12,b10*0+(10-1)*(D+d),z2);
hold on 
surf(a12,b10*0+(10-1)*(D+d)+D,z2);
hold on 
surf(a12*0+(12-1)*(D+d),b10,z3);
hold on 
surf(a12*0+(12-1)*(D+d)+D,b10,z3);

%% 3_4-23
T23=T23/T;
z1=zeros(1+D*10,1+D*10)+T23;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T23/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T23/(D*10);
end
surf(a12,b8,z1);
hold on 
surf(a12,b8*0+(8-1)*(D+d),z2);
hold on 
surf(a12,b8*0+(8-1)*(D+d)+D,z2);
hold on 
surf(a12*0+(12-1)*(D+d),b8,z3);
hold on 
surf(a12*0+(12-1)*(D+d)+D,b8,z3);

%% 3_4-24
T24=T24/T;
z1=zeros(1+D*10,1+D*10)+T24;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T24/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T24/(D*10);
end
surf(a12,b11,z1);
hold on 
surf(a12,b11*0+(11-1)*(D+d),z2);
hold on 
surf(a12,b11*0+(11-1)*(D+d)+D,z2);
hold on 
surf(a12*0+(12-1)*(D+d),b11,z3);
hold on 
surf(a12*0+(12-1)*(D+d)+D,b11,z3);

%% 3_4-34
T34=T34/T;
z1=zeros(1+D*10,1+D*10)+T34;
for i=1:1:1+D*10 
    z2(i,:)=z1(i,:)-(i-1)*T34/(D*10);
    z3(:,i)=z1(:,i)-(i-1)*T34/(D*10);
end
surf(a12,b12,z1);
hold on 
surf(a12,b12*0+(12-1)*(D+d),z2);
hold on 
surf(a12,b12*0+(12-1)*(D+d)+D,z2);
hold on 
surf(a12*0+(12-1)*(D+d),b12,z3);
hold on 
surf(a12*0+(12-1)*(D+d)+D,b12,z3);


shading flat%网格化

p1=0:0.1:(12-1)*(D+d)+D;
q1=(12-1)*(D+d)+D+0*p1;
z1=1+0*p1;
plot3(p1,q1,z1,'color',[0.75 0.75 0.75],'linewidth',1);

q2=0.1:0.1:(12-1)*(D+d)+D;
p2=(12-1)*(D+d)+D+0*q2;
z2=1+0*q2;
plot3(p2,q2,z2,'color',[0.75 0.75 0.75],'linewidth',1);

z3=0:0.1:1;
p3=0+0*z3;
q3=(12-1)*(D+d)+D+0*z3;
p4=(12-1)*(D+d)+D+0*z3;
q4=(12-1)*(D+d)+D+0*z3;
p5=(12-1)*(D+d)+D+0*z3;
q5=0.1+0*z3;
plot3(p3,q3,z3,'color',[0.75 0.75 0.75],'linewidth',1);
hold on
plot3(p4,q4,z3,'color',[0.75 0.75 0.75],'linewidth',1);
hold on
plot3(p5,q5,z3,'color',[0.75 0.75 0.75],'linewidth',1);

% q6=(12-1)*(D+d)+D:0.1:(12-1)*(D+d)+D+0.6*D;
% p6=0*q6;
% z6=0+0*q6;z7=0.5+0*q6;z8=1+0*q6;
% plot3(p6,q6,z6,'color',[0 0 0],'linewidth',1.5);
% hold on
% plot3(p6,q6,z7,'color',[0 0 0],'linewidth',1.5);
% hold on
% plot3(p6,q6,z8,'color',[0 0 0],'linewidth',1.5);
% 
% for i=1:1:12
%     p=-0.6*D:0.1:0;
%     q=(i-1)*(D+d)+0.5*D+0*p;
%     z=0*p;
%     plot3(p,q,z,'color',[0 0 0],'linewidth',1.5);
%     hold on
% end
% 
% for i=1:1:12
%     q=-0.6*D:0.1:0;
%     p=(i-1)*(D+d)+0.5*D+0*q;
%     z=0*q;
%     plot3(p,q,z,'color',[0 0 0],'linewidth',1.5);
%     hold on
% end

colorbar; colormap(hot);
clim([0 1]);
view(-64.8131,76.8)

set(gca,'xcolor',[1 1 1]);
set(gca,'ycolor',[1 1 1]);
set(gca,'zcolor',[1 1 1]);
set(gcf,'color',[1 1 1]);


